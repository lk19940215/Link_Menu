// TODO: 用户名称需修改为自己的名称
var userName = '丁冰冰';
// 朋友圈页面的数据
var data = [{
	user: {
		name: '阳和',
		avatar: './img/avatar2.png'
	},
	content: {
		type: 0, // 多图片消息
		text: '华仔真棒，新的一年继续努力！',
		pics: ['./img/reward1.png', './img/reward2.png', './img/reward3.png', './img/reward4.png'],
		share: {},
		timeString: '3分钟前'
	},
	reply: {
		hasLiked: false,
		likes: ['Guo封面', '源小神'],
		comments: [{
			author: 'Guo封面',
			text: '你也喜欢华仔哈！！！'
		}, {
			author: '喵仔zsy',
			text: '华仔实至名归哈'
		}]
	}
}, {
	user: {
		name: '伟科大人',
		avatar: './img/avatar3.png'
	},
	content: {
		type: 1, // 分享消息
		text: '全面读书日',
		pics: [],
		share: {
			pic: 'http://coding.imweb.io/img/p3/transition-hover.jpg',
			text: '飘洋过海来看你'
		},
		timeString: '50分钟前'
	},
	reply: {
		hasLiked: false,
		likes: ['阳和'],
		comments: []
	}
}, {
	user: {
		name: '深圳周润发',
		avatar: './img/avatar4.png'
	},
	content: {
		type: 2, // 单图片消息
		text: '很好的色彩',
		pics: ['http://coding.imweb.io/img/default/k-2.jpg'],
		share: {},
		timeString: '一小时前'
	},
	reply: {
		hasLiked: true,
		likes: [],
		comments: []
	}
}, {
	user: {
		name: '喵仔zsy',
		avatar: './img/avatar5.png'
	},
	content: {
		type: 3, // 无图片消息
		text: '以后咖啡豆不敢浪费了',
		pics: [],
		share: {},
		timeString: '2个小时前'
	},
	reply: {
		hasLiked: false,
		likes: [],
		comments: []
	}
}];

// 相关 DOM
var $page = $('.page-moments');
var $momentsList = $('.moments-list');


/*
 * 这里需要添加对 repply.haslike的判断。将其作为参数传入，与另写一个方法相比，代码量更少。
 * */

/**
 * 点赞内容 HTML 模板
 * @param {Array} likes 点赞人列表
 * @return {String} 返回html字符串
 */
function likesHtmlTpl(likes, userLike) {
	if(!likes.length && !userLike) {
		return '';
	}
	var htmlText = ['<div class="reply-like"><i class="icon-like-blue"></i>'];
	if(likes.length) {
		htmlText.push(' <a class="reply-who" href="#">' + likes[0] + '</a>');
	}
	
	// 后面的前面都有逗号 
	for(var i = 1, len = likes.length; i < len; i++) {
		htmlText.push('，<a class="reply-who" href="#">' + likes[i] + '</a>');
	}
	
	/*
	 * 以下为新添加的对 repply.haslike 处理的代码 
	 * 将‘，’写入 a 标签，方便当前用户后续取消点赞删除文字
	 * 同时，使用三元表达式，若只有用户点赞，应该没有‘，’符号
	 * 
	 * 代码形式等同于 if (userLike) { htmlText.push(******) }
	 * */
	
	 (userLike) && (htmlText.push('<a class="reply-who" href="#">' + (likes.length ? '，' : '') + userName + '</a>'));
	
	htmlText.push('</div>');
	return htmlText.join('');
}
/**
 * 评论内容 HTML 模板
 * @param {Array} comments 评论人列表
 * @return {String} 返回html字符串
 */
function commentsHtmlTpl(comments) {
	if(!comments.length) {
		return '';
	}
	var htmlText = ['<div class="reply-comment">'];
	for(var i = 0, len = comments.length; i < len; i++) {
		var comment = comments[i];
		htmlText.push('<div class="comment-item"><a class="reply-who" href="#">' + comment.author + '</a>：' + comment.text + '</div>');
	}
	htmlText.push('</div>');
	return htmlText.join('');
}

/*
 * 下面likesHtmlTpl()有变动
 * */

/**
 * 评论点赞总体内容 HTML 模板
 * @param {Object} replyData 消息的评论点赞数据
 * @return {String} 返回html字符串
 */
function replyTpl(replyData) {
	var htmlText = [];
	htmlText.push('<div class="reply-zone">');
	htmlText.push(likesHtmlTpl(replyData.likes, replyData.hasLiked)); 
	htmlText.push(commentsHtmlTpl(replyData.comments));
	htmlText.push('</div>');
	return htmlText.join('');
}

/**
 * 多张图片消息模版 （可参考message.html）
 * @param {Array} pics 多图片消息的图片列表
 * @return {String} 返回html字符串
 */
function multiplePicTpl(pics) {
	var htmlText = [];
	htmlText.push('<ul class="item-pic">');
	for(var i = 0, len = pics.length; i < len; i++) {
		htmlText.push('<img class="pic-item" src="' + pics[i] + '">')
	}
	htmlText.push('</ul>');
	return htmlText.join('');
}

/**
 * 分享消息模版
 * @param {Object} share 分享内容
 * @return {String} 返回html字符串
 */
function shareTpl(share) {
	var htmlText = [];
	htmlText.push('<div class="item-share">');
	htmlText.push('<img class="share-img" src="' + share.pic + '">');
	htmlText.push('<span class="share-tt">' + share.text + '</span>');
	htmlText.push('</div>');
	return htmlText.join('');
}

/**
 * 单图片消息模版
 * @param {Array} pics 单图片
 * @return {String} 返回html字符串
 */
function singlePicTpl(pics) {
	var htmlText = [];
	htmlText.push('<div class="item-only-img">');
	htmlText.push('<img class=".item-pic" src="' + pics[0] + '">');
	htmlText.push('</div>');
	return htmlText.join('');
}

/* 代码有变动
 * 将 点赞，评论框的HTML代码，在messageTpl()中,就进行预添加
 * */

/**
 * 循环：消息体 
 * @param {Object} messageData 对象
 */
function messageTpl(messageData) {
	var user = messageData.user;
	var content = messageData.content;
	var htmlText = [];
	htmlText.push('<div class="moments-item" data-index="0">');
	// 消息用户头像
	htmlText.push('<a class="item-left" href="#">');
	htmlText.push('<img src="' + user.avatar + '" width="42" height="42" alt=""/>');
	htmlText.push('</a>');
	// 消息右边内容
	htmlText.push('<div class="item-right">');
	// 消息内容-用户名称
	htmlText.push('<a href="#" class="item-name">' + user.name + '</a>');
	// 消息内容-文本信息
	htmlText.push('<p class="item-msg">' + content.text + '</p>');
	// 消息内容-图片列表 
	var contentHtml = '';
	// 目前只支持多图片消息，需要补充完成其余三种消息展示
	switch(content.type) {
		// 多图片消息
		case 0:
			contentHtml = multiplePicTpl(content.pics);
			break;
		case 1:
			// TODO: 实现分享消息
			contentHtml = shareTpl(content.share);
			break;
		case 2:
			//  TODO: 实现单张图片消息
			contentHtml = singlePicTpl(content.pics);
			break;
		case 3:
			//  TODO: 实现无图片消息
			break;
	}
	htmlText.push(contentHtml);
	// 消息时间和回复按钮
	htmlText.push('<div class="item-ft">');
	htmlText.push('<span class="item-time">' + content.timeString + '</span>');
	htmlText.push('<div class="item-reply-btn">');
	htmlText.push('<span class="item-reply"></span>');
	htmlText.push('</div></div>'); //**** 此处要改写
	
	/* 上句代码 htmlText.push('</div>')
	 * 建议的 点赞，评论HTML代码添加
	 * */
//	htmlText.push('</div>');  //此处替换上句 ****代码
//	htmlText.push('<div class="reply-alert">');
//	htmlText.push('<div class="like-btn"><i class="icon-like"></i><span class="text-like">点赞</span></div>');
//	htmlText.push('<div class="comment-btn"><i class="icon-comment"></i><span class="text-comment">评论</span></div>');
//	htmlText.push('</div></div>');
	
	// 消息回复模块（点赞和评论）
	htmlText.push(replyTpl(messageData.reply));
	htmlText.push('</div></div>');
	return htmlText.join('');
}


/* 注意for循环、forEach()方法的使用。
 * 
 * 这里添加了很多多余的代码。尽管这里的数据就4个
 * 但是，真实项目数据都从后台传入，如果后台给你的是一个几十个元素的数组呢？
 * 
 * 同时，就函数式编程的思想而言，数据，目标DOM，应该都是使用参数传入
 * 这样耦合性才能最小，不出现一处代码改动，整体代码要多处改动的情况
 */

/**
 * 页面渲染函数：render
 */

function render(Dom, data) {
	// TODO: 目前只渲染了一个消息（多图片信息）,需要展示data数组中的所有消息数据。
	var messageHtml = messageTpl(data[0]);
	$momentsList.html(messageHtml);
	var messageHtml2 = messageTpl(data[1]);
	$momentsList.append(messageHtml2);
	var messageHtml3 = messageTpl(data[2]);
	$momentsList.append(messageHtml3);
	var messageHtml4 = messageTpl(data[3]);
	$momentsList.append(messageHtml4);
	
	/*	for (var i = 0; i < data.length; i++) {
	 *		Dom.append(messageTpl(data[i]));
	 *	}
	 */
}

/**
 * 页面绑定事件函数：bindEvent
 */
function bindEvent() {
	// TODO: 完成页面交互功能事件绑定

	/** 
	 *事件一:实现回复功能
	 */
	/*
	 * （无关大雅的批阅）
	 * 前文有 注册 $momentsList 变量，却不使用？ 
	 * 这里这样写，虽然不会对功能有什么影响，但很容易造成一种自己写了什么代码，自己都不知道的假象
	 * 就优化而言，jQuery又做了一次无用DOM检索。
	 * 就变量格式规范而言，使用jQuery 大家默认 $thisBtn 的形式，表示是一个jQuery代理对象
	 * 而 _thisBtn 表示私有变量，不对外暴露，不对外使用
	 * 
	 * 以下只是建议
	 * 建议将  点赞，回复的HTML, 在render()初步处理中就添加
	 * 而点赞框、评论框的 滑动动画，通过CSS类名的增删来实现
	 * 然后，就只需 _thisReplyBorder.addClass/removeClass('active') 就可以实现效果了
	 * 
	 * 比如，在你的代码中，默认下 .reply-alert right为-120px
	 * 那么,.active下 ，right 则为 40px, 配合 css3特性 transition: right 0.5s即可实现效果（css代码有批阅）
	 * 
	 * 于是以下的代码可以这么写(此时，HTML已经在render()中添加)
	 * 	
	 * $momentsList.on('click', '.item-reply-btn', function(e){  // e 为event对象
	 * 	var $that = $(this);
	 * 	var result = $that.next().hasClass('active');  // 用于当前按钮的切换
	 *  var _hasShow = $momentsList.find('.reply-alert').filter('.active'); // 获取显示的ODM
	 *  	if (result) {
	 * 	 		$that.next().removeClass('active');
	 * 		} else {
	 * 			if (e.target !== _hasShow) {  		// 添加之前隐藏另一个消息的按钮栏
	 * 				_hasShow.removeClass('active'); 
	 * 			}
	 * 			$that.next().addClass('active');
	 * 		}
	 * });
	 * 
	 * */
	
	$('.moments-list').on('click', '.item-reply-btn', function() {
		var _thisBtn = $(this);
		var _thisReplyBorder = _thisBtn.parents('.moments-item').find('.reply-alert');
		
		/* 点击其它消息类型下的按钮栏，已经显示的按钮栏未做隐藏操作
		 * 
		 * 方法同上方示例，改变之前，获取已经显示的DOM，对比当前DOM，是同一个则不做操作
		 * 不是的，隐藏已经显示的，显示当前点击的。
		 * */
		if(_thisReplyBorder.html()) {
			if(_thisReplyBorder.css('right') == '40px') {
				removeReplyBorder(_thisBtn);
			} else {
				alertReply(_thisBtn);
			}
		} else {
			addReplyBorder(_thisBtn);
			alertReply(_thisBtn);
		}
		return false;
	});
	
	
	//添加回复框HTML
	function addReplyBorder(btn) {
		var commentHTML = [];
		commentHTML.push('<div class="reply-alert">');
		commentHTML.push('<div class="like-btn"><i class="icon-like"></i><span class="text-like">点赞</span></div>');
		commentHTML.push('<div class="comment-btn"><i class="icon-comment"></i><span class="text-comment">评论</span></div>');
		commentHTML.push('</div>');
		btn.parents('.item-ft').append(commentHTML.join(''));
	}
	
	/* 要学会js、css代码的分离
	 * */
	//移除回复框HTML
	function removeReplyBorder(btn) {
		btn.parents('.moments-item').find('.reply-alert').animate({
			right: '-120px'
		});
	}
	//点击弹出回复框函数
	function alertReply(btn) {
		btn.parents('.moments-item').find('.reply-alert').animate({
			right: '40px'
		});
	}
	/* 
	 * 还应该对input框做value清空，隐藏的处理
	 * 
	 * */
	
	//点击其他地方隐藏回复框
	$('body').click(function() {
		$('.reply-alert').animate({
			right: '-120px'
		});
		// $('input').val('') 类似如此
	});

	/*
	 * 若reply.hasLike 为true,则整个代码逻辑都是有错误的。
	 * */

	/**
	 *事件二：点赞功能实现
	 */
	//根据类名标记决定点赞事件行为
	$('.moments-list').on('click', '.like-btn', function() {
		var _thisBtn = $(this);
		if(_thisBtn.hasClass('unlike-btn')) {
			removeLikeName(_thisBtn);
			/*忘记将文字改变为“点赞”，一个语句可以不用单独写一个函数
			 * */
			// _thisBtn.find('.text-like').text('点赞');
		} else {
			changeReplyBorder(_thisBtn);
			addLikeName(_thisBtn);
		}
	});

	//点赞后改变回复框文字
	function changeReplyBorder(btn) {
		/* btn本来就是'.text-like'的父元素，使用parents('.moments-item')很多余
		 * */
		btn.parents('.moments-item').find('.text-like').text('取消');
	}
	//点赞后将名字添加到赞列表
	function addLikeName(btn) {
		
		/*.reply-zone 包含 .reply-like 故，没必要再次检索，利用前一变量再次find即可
		 *_likeList = _replyZone.find('.reply-like')
		 * 
		 * btn.addClass('unlike-btn');  // 为共有语句，可以提出
		 * 
		 * _likeList.append('，<a class="reply-who" href="#">' + userName + '</a>');
		 * 符号"，" 可以放入<a>标签中，或单独放入一个i标签中，方便后续进行删除
		 * */
		var _likeList = btn.parents('.moments-item').find('.reply-like');
		var _replyZone = btn.parents('.moments-item').find('.reply-zone');
		if(_likeList.html()) {
			_likeList.append('，<a class="reply-who" href="#">' + userName + '</a>');
			btn.addClass('unlike-btn');  
		} else {
			_replyZone.prepend('<div class="reply-like"><i class="icon-like-blue"></i><a class="reply-who" href="#">' + userName + '</a></div>');
			btn.addClass('unlike-btn');  
		}
	}
	//取消点赞后从点赞列表删除名字
	
	/* 此处，因为'.reply-who :last' 中间的' ' 空白字符，导致DOM检索失败
	 * 从而导致取消点赞功能未实现（当前用户文字未成功删除）
	 * 
	 * 正确格式为.reply-who:last，CSS选择器需要进行复习
	 * 
	 * 不推荐使用.html()来判断只有当前用户点赞，但符合功能实现
	 * */
	function removeLikeName(btn) {
		var _myLike = btn.parents('.moments-item').find('.reply-like').find('.reply-who :last');
		
		_myLike.remove();
		btn.removeClass('unlike-btn');
		if(!btn.parents('.moments-item').find('.reply-who').html()) {
			btn.parents('.moments-item').find('.reply-like').remove();
		}
	}
	
	/* 已定义 $page = $('.page-moments')
	 * 建议将评论框的HTML代码写入 moments.html中，通过CSS控制隐藏
	 * 在隐藏评论框时，也更容易
	 * （参考前面点赞，评论的显示隐藏——通过添加active类名实现）
	 * 
	 * 过多的代码来添加评论框代码。
	 * _commentBtn 如果是外部要使用，用全局变量保存，而不是在函数内 省略var，虽然一样可以达到全局声明的效果
	 * */
	
	/** 
	 *事件三：评论功能实现
	 */
	$('.page-moments').on('click', '.comment-btn', function() {
		_commentBtn = $(this);
		var inputHtml = [];
		inputHtml.push('<div class="comment-input"><input type="text" class="input-content" autofocus><input type="button" class="input-submit" value="关闭"></div>');
		$('.page-moments').append(inputHtml.join(''));
	});
	return false;
}

/* 事件，推荐使用on绑定， 而且，应该事件到input框上
 * 虽然可以事件冒泡到$('.page-moments')上，但要养成良好的编程习惯
 * 
 * $('.input-content').on('click', function(){
 * 		if (this.value) {
 * 	  		// code
 * 		}
 * 		// code
 * })
 * */

// 若输入文字则按钮激活
	
$('.page-moments').bind('input', function() {
	if($('.input-content').val() != '') {
		$('.input-submit').css('background-color', '#54CB30').val('评论');
	}
});

// 若没有输入文字则按钮未激活
$('.page-moments').keyup(function() {
	if($('.input-content').val() == '') {
		$('.input-submit').css('background-color', '#ccc');
	}
});

/* _commentBtn 应在全局中声明，在上方函数内这样定义（省略var），是不符合规范的。
 * 建议通过类名控制输入框的显示隐藏
 * */
//点击评论按钮，获取评论内容并添加到页面
$('.page-moments').on('click', '.input-submit', function() {
	
	var commentTxt = $('.input-content').val();
	var replyComment = _commentBtn.parents('.moments-item').find('.reply-comment');
	if(commentTxt != '') {
		if(replyComment.html()) {
			replyComment.append('<div class="comment-item"><a class="reply-who" href="#">' + userName + '</a>：' + commentTxt + '</div>');
		} else {
			var replyZone = _commentBtn.parents('.moments-item').find('.reply-zone');
			replyZone.append('<div class="reply-comment"><div class="comment-item"><a class="reply-who" href="#">' + userName + '</a>：' + commentTxt + '</div></div>');
		}
	}
	$('.comment-input').animate({
		top: '100vh'
	}).remove();
});

/**
 * 事件四：点击图片放大显示
 */
$('.moments-list').on('click', '.item-right img', function() {
	var imgWrapHtml = [];
	imgSrc = $(this).attr('src');
	imgWrapHtml.push('<div class="img-wrap"><img src=');
	imgWrapHtml.push(imgSrc);
	imgWrapHtml.push('></div>');
	$('body').append(imgWrapHtml.join(''));
});

//点击大图则取消浏览
$('body').on('click', '.img-wrap img', function() {
	$('.img-wrap').remove();
});

/**
 * 页面入口函数：init
 * 1、根据数据显示页面内容
 * 2、绑定事件
 */
function init() {
	// 渲染页面
	render($momentsList, data);
	bindEvent();
}

init();