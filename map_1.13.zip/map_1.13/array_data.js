[
	{
		"name": "华南",
		"data": [
			{
				"name": "深圳龙华",
				"value": 169
			},
			{
				"name": "深圳观澜",
				"value": 145
			},
			{
				"name": "深圳松岗",
				"value": 169
			}
		]
	}
]
