$(function() {
	var _table_1 = document.getElementById('tab_1'),
		_table_2 = document.getElementById('tab_2'),
		_table_3 = document.getElementById('tab_3'),
		_table_4 = document.getElementById('tab_4');

	var $width = $(window).width(),
		$btn_wrapper = $('#btn-wrapper'),
		$info = $('.info'),
		$city_cell = $('.city_cell'),
		$tab_centent = $('.tab_centent div');

	var $text_large = [34, 28, 15, 12],
		$text_medium = [28, 20, 12, 11],
		$text_small = [20, 17, 10, 8],
		$title_Top = ['40px', '40px', '30px'],
		$title_Left = ['35px', '20px', '16px'];

	var result = true,
		myData = [],
		_fontSize = [],
		_titleTop,
		_titleLeft,
		EchartConfig = {},
		option = {};

	if($width >= 1220) {
		_fontSize = $text_large;
		_titleTop = $title_Top[0];
		_titleLeft = $title_Left[0];
	} else if($width >= 768 && $width < 1220) {
		_fontSize = $text_medium;
		_titleTop = $title_Top[1];
		_titleLeft = $title_Left[1];
	} else {
		_fontSize = $text_small;
		_titleTop = $title_Top[2];
		_titleLeft = $title_Left[2];
	}

	EchartConfig = {
		center: [
			[115.31, 37.52],
			[88.31, 37.52]
		],
		title: {
			styleOne: {
				left: _titleLeft,
				top: _titleTop,
				textStyle: {
					rich: {
						text: {
							fontSize: _fontSize[1]
						}
					}
				}
			},
			styleTwo: {
				left: '14%',
				top: '14%',
				textStyle: {
					rich: {
						text: {
							fontSize: _fontSize[0]
						}
					}
				}
			}
		}
	};

	option = {
		title: {
			text: '{text|富士康科技集团大陆人力布局}',
			left: '14%',
			top: '14%',
			textStyle: {
				rich: {
					text: {
						fontSize: _fontSize[0],
						color: '#ec861d',
						fontWeight: 'bold',
						textBorderWidth: '3',
						textBorderColor: '#FFFFFF',
						align: 'center',
						borderRadius: 5
					}
				}
			}
		},
		geo: {
			silent: true, //关闭事件响应
			map: 'china',
			roam: true,
			zoom: 1.1,
			scaleLimit: {
				min: 1.05,
				max: 10
			},
			center: EchartConfig.center[0], //视角中心
			label: {
				normal: {
					show: true,
					fontSize: _fontSize[2],
					fontFamily: 'PMingLiU',
					distance: 20,
					color: '#d0d0d0'
				},
				emphasis: {
					show: false
				}
			},
			itemStyle: {
				normal: {
					areaColor: '#fffddc',
					borderColor: '#3086d1'
				},
				emphasis: {
					areaColor: '#fffddc'
				}
			}
		},
		backgroundColor: {
			type: 'radial',
			x: 0.5,
			y: 0.5,
			r: 1,
			colorStops: [{
				offset: 0.2,
				color: '#58c4f3' //'rgba(95, 198, 241, 0.96)'
			}, {
				offset: 1,
				color: '#0064b1'
			}],
			globalCoord: false // 缺省为 false
		},
		tooltip: {
			trigger: 'item' // 悬浮显示
		},
		series: [{
			name: '人力数据',
			type: 'scatter',
			coordinateSystem: 'geo',
			data: myData,
			label: {
				normal: {
					formatter: function(obj) {
						var str = ['{text|' + obj.name + '}', '{value|' + obj.data.value[2] + '}'];
						return str.join('\n');
					},
					distance: 4,
					position: 'bottom',
					show: true,
					rich: {
						text: {
							color: '#3e4182',
							fontSize: _fontSize[2],
							fontWeight: '500',
							fontFamily: 'PMingLiU',
							align: 'center'
						},
						value: {
							color: '#b35751',
							fontSize: _fontSize[3],
							align: 'center'
						}
					}
				},
				emphasis: {
					show: true
				}
			},
			symbolSize: 10,
			encode: {
				tooltip: [2] // 数据解析 方便悬浮显示
			},
			itemStyle: {
				normal: {
					color: {
						type: 'radial',
						x: 0.5,
						y: 0.5,
						r: 1,
						colorStops: [{
							offset: 0.2,
							color: 'rgba(254, 180, 22, 0.84)'
						}, {
							offset: 0.7,
							color: '#a77305'
						}],
						globalCoord: false
					}
				}
			}
		}]
	};
	myChart = echarts.init(document.getElementById('map-wrapper'));
	myChart.setOption(option);
	myChart.showLoading();

	$btn_wrapper.find('label').on('click', function(e) {
		if(!result) {
			alert('请开启表格显示！')
			return false;
		}
		var _index = $(this).index();
		$tab_centent.eq(_index).removeClass('hide').addClass('show').siblings().filter('.table_hock').removeClass('show').addClass('hide');

		if(_index === 1) {
			myChart.setOption({
				title: EchartConfig.title.styleOne,
				geo: {
					center: EchartConfig.center[1] // 中心位置坐标
				}
			});
			$info.find('.info_num').addClass('active');
		} else {
			myChart.setOption({
				title: EchartConfig.title.styleTwo,
				geo: {
					center: EchartConfig.center[0] // 中心位置坐标
				}
			});
			$info.find('.info_num').removeClass('active');
		}
	});

	$btn_wrapper.find('.btn_show').on('click', function() {
		var $this = $(this),
			_result = $this.parent().hasClass('hide');
		_result ? $this.text('关闭工具栏') : $this.text('显示工具栏');
		$this.parent().toggleClass('hide').toggleClass('show');
	});

	$btn_wrapper.find('.toggle input').on('click', function() {
		result = $(this).prop('checked');
		$tab_centent.filter('.table_hock.show').toggleClass('hide');
	});

	$('#city_hide').on('click', function() {
		$(this).parents('.tab_item4').removeClass('show').addClass('hide');
	});
	
	myChart.on('click', function(e) { // 点击事件
		var obj = { x: 0,y: 0 };
		if(e.name !== "深圳") {
			loadCityTable(e.name);
		} else {
			obj = {
				x: e.event.offsetX - 85,
				y: e.event.offsetY - 60
			}
			$city_cell.removeClass('hide').addClass('show').css({
				top: obj.y,
				left: obj.x
			}).find('input:checked').prop('checked', false);
			e.event.event.stopPropagation();
			e.event.event.preventDefault();
		}
	});
	
	myChart.on('click', function(e, a) { // 点击事件
		console.log(1)
	});
	
	
	
	$city_cell.find('label input').on('click', function(e) {
		var _value = this.value;
		loadCityTable(_value);
		e.stopPropagation();
	});
	$(document).on('click', function(e) {
		var $cell_city = $(e.target).parents('div'),
			result = $cell_city.hasClass('city_cell');

		if(!result && $city_cell.hasClass('show')) {
			$city_cell.removeClass('show').addClass('hide');
		}
	});
	$(window).on('resize', function() {
		window.location.reload();
	});
	
	/* 给的链接 http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx?action=getEmpBySJT_DM&From=1
	 * 
	 *	$.get('http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx', {action: 'getEmpBySJT_DM', From: "1"})
	 *		.then(function(response) {
	 *		
	 * 		})
	 * */
	
	$.ajax({
		url: './table_data.json', // http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx
		data: {
			action: 'getEmpBySJT_DM',
			From: "1"
		},
		dataType: 'json'
	}).then(function(response) { 
		var regx = /(\w+)-(\w+)-(\w+)/,
			str;
			
		regx.exec(response.time);
		str = RegExp.$1 + '年' + RegExp.$2 + '月' + RegExp.$3 + '日';
		
		
		window.myTable({
			target: _table_1,
			hide_item: true,
			hide_count: true,
			item_count: true,
		}, response);

		window.myTable({
			target: _table_2
		}, response);

		window.myTable({
			count_colSpanLength: 3,
			target: _table_3,
			hide_item: true,
			hide_count: true,
			hide_address: true,
			item_count: true
		}, response);

		$info.removeClass('hidden');

		$info.find('.info_num .num').text(formatterNum(response.totalValue)).end()
			.find('.info_time .time').text(str);
	});
	
	/* 给的链接 http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx?action=getEmpByFac_DM&From=1
	 * 
	 *	$.ajax({
	 *		url: 'http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx',
	 *		data: {
	 *			"action": "getEmpByFac_DM",
	 * 			"From": 1  
	 *		}
	 *	});
	 */	
	
	$.ajax({
		url: './data.json', //'http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx',
		data: {
		    "action": "getEmpByFac_DM",
		    "From": 1  
		},
		dataType: 'json'
	})
	.then(function(response) {
		myData = response;
		myChart.hideLoading();
		myChart.setOption({
			series: [{
				data: convertData(myData)
			}]
		});
	});
	
	
	function loadCityTable(name) {
		$tab_centent.eq(3).removeClass('hide').addClass('show').find('thead .th_count').remove().end().find('tbody').empty();
	/* 给的链接 http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx?action=getEmpByFacClass_DM&FacName=%E6%88%90%E9%83%BD
	 * 
	 *	$.ajax({
	 *		url: 'http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx',
	 *		data: {
	 *			"action": "getEmpByFacClass_DM",
	 *			"FacName": name  // 这可能需要使用encodeURIComponent()
	 *		},
	 *		success: function(res) { }
	 *	});
	 */	
		$.ajax({
			url: 'cell_data.json', // 'http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx',
			data: {
				"action": "getEmpByFacClass_DM",
				"FacName": name
			},
			dataType: 'json'
		}).then(function(res){
				window.cityTable({
					target: _table_4,
				}, res);
		});
	}
	
	function convertData(data) {
		var res = [],
			configArr;
		configArr = geoConfig.filter(function(item) {
			return item.label !== undefined;
		});
		data.forEach(function(item) { // 混合config的位置配置(并减少循环次数)
			for(var i = 0; i < configArr.length; i++) {
				var result = configArr[i].name === item.name;
				if(result) {
					item['label'] = configArr[i].label;
					configArr.splice(i, 1);
					return !result;
				}
			}
		});
		for(var i = 0; i < data.length; i++) {
			var geoCoord = geoCoordMap[data[i].name];
			if(geoCoord) {
				if(data[i]['label']) {
					res.push({
						name: data[i].name,
						value: geoCoord.concat(data[i].value),
						label: data[i]['label']
					});
				} else {
					res.push({
						name: data[i].name,
						value: geoCoord.concat(data[i].value)
					});
				}
			}
		}
		return res;
	}
	
	function formatterNum(num) {
		var arr = [],
			str = '';
		num = num + '';
		arr = num.split('').reverse();
		for(var i = 0; i < arr.length; i++) {
			str += ((i % 3 !== 0) ? '' : ',') + arr[i];
		}
		return str.substring(1).split('').reverse().join('');
	}
});