//删除掉的JS代码

	
//		//保存按钮
//		$("table tbody").on("click", ".save-btn", function() {
//			/*-------BUG 编辑的信息，没有在_data里面找到------*/
//			var _id = $(".tab-content .tab-pane.active")[0].id;
//			var id =$(this).attr("id");
//			var tds = $(this).parents("tr").children();
//			var sTds = tds.length;
//			var table;
//			var _data = 1;
//
//			if (_id == "hr1"){
//				table = table1;  //此处代码用于判断删除操作发生在哪个表格。 如果有两处代码，不需要写重复代码；
//			}else{
//				table = table2;
//			}
//			$.each(tds, function(i, val) {
//					var jqob = $(val);
//					//把input变为字符串
//					if (!jqob.has('i').length) {
//						var txt = jqob.children("input").val();
//						jqob.html(txt);
//					}
//				});
//			_data = table.data();
//			console.log(_data)
//			$(this).html("编辑");
//			$(this).toggleClass("edit-btn").toggleClass("save-btn");
//			sendTosever(_data);
//			
//		});	




//				var tds = $(this).parents("tr").children();
//				var i;
//				var _length = tds.size();
//				$.each(tds, function(i, val) {
//					var jqob = $(val);
//					var txt = jqob.text();
//					if (i < _length-1) {
//						var put = $("<input type='text' style='width:80%'>");
//						put.val(txt);
//						jqob.html(put);
//					}
//				});
//				$(this).html("保存");
//				$(this).toggleClass("edit-btn").toggleClass("save-btn");