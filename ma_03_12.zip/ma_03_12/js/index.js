$(function() {
	
	// 四个表格的DOM获取
	var _table_1 = document.getElementById('tab_1'),
		_table_2 = document.getElementById('tab_2'),
		_table_3 = document.getElementById('tab_3'),
		_table_4 = document.getElementById('tab_4');
	
	// 其它相关的DOM节点获取
	var $width = $(window).width(),
		$btn_wrapper = $('#btn-wrapper'),
		$form_date = $btn_wrapper.find('.form_date'),
		$info = $('.info'),
		$city_cell = $('.city_cell'),
		$tab_centent = $('.tab_centent div');
	
	// 不同分辨率下，Echarts相关的配置
	var $text_large = [34, 28, 15, 12],
		$text_medium = [28, 20, 12, 11],
		$text_small = [20, 17, 10, 8],
		$title_Top = ['40px', '40px', '30px'],
		$title_Left = ['35px', '20px', '16px'];

	var result = true, 		// 是否开启了表格显示的判断标志
		myData = [],		// 用于Echarts展示数据存储的变量
		_fontSize = [], 	// Echarts配置
		_titleTop,			// Echarts配置
		_titleLeft,			// Echarts配置
		date = Date.now(),	// 获取页面打开的时间（四个表格都要带入访问的日期）
		EchartConfig = {},	// Echarts配置
		option = {};		// Echarts配置
	
	// 获取是否登录的localstorage标志（在login.js中有有关的JS代码）
	var Login = Boolean(sessionStorage.getItem('isLogin'));
	
	//	若 Login为false(未登录，直接访问了hr_emp页面)
	if (!Login) {
		// 强制URL跳转到login页面，并return false跳出，结束
		var URL = window.location.origin + window.location.pathname;
		URL = URL.replace('hr_emp.html', 'login.html')
		window.location.href = URL
		return false;
	}
	
	// 用于页面初始打开时，默认访问本日期的数据
	date = new Date(date).getFullYear() + '-' + ((new Date(date).getMonth() + 1) < 10 ? '0' + (new Date(date).getMonth() + 1) : new Date(date).getMonth() + 1 ) + '-' + (new Date(date).getDate() < 10 ? '0' + new Date(date).getDate() : new Date(date).getDate());
	
	// 不同屏幕宽度下，Echarts的配置
	if($width >= 1220) {
		_fontSize = $text_large;
		_titleTop = $title_Top[0];
		_titleLeft = $title_Left[0];
	} else if($width >= 768 && $width < 1220) {
		_fontSize = $text_medium;
		_titleTop = $title_Top[1];
		_titleLeft = $title_Left[1];
	} else {
		_fontSize = $text_small;
		_titleTop = $title_Top[2];
		_titleLeft = $title_Left[2];
	}
	
	// Echarts标题的配置
	EchartConfig = {
		center: [
			[115.31, 37.52],
			[88.31, 37.52]
		],
		title: {
			styleOne: {
				left: _titleLeft,
				top: _titleTop,
				textStyle: {
					rich: {
						text: {
							fontSize: _fontSize[1]
						}
					}
				}
			},
			styleTwo: {
				left: '14%',
				top: '11%',
				textStyle: {
					rich: {
						text: {
							fontSize: _fontSize[0]
						}
					}
				}
			}
		}
	};
	
	// Echarts主配置
	option = {
		title: {
			text: '{text|富士康科技集团大陆人力布局}',
			left: '14%',
			top: '11%',
			textStyle: {
				rich: {
					text: {
						fontSize: _fontSize[0],
						color: '#ec861d',
						fontWeight: 'bold',
						textBorderWidth: '3',
						textBorderColor: '#FFFFFF',
						align: 'center',
						borderRadius: 5
					}
				}
			}
		},
		geo: {
			silent: true, //关闭事件响应
			map: 'china',
			roam: true,
			zoom: 1.1,
			scaleLimit: {
				min: 1.05,
				max: 10
			},
			center: EchartConfig.center[0], //视角中心
			label: {
				normal: {
					show: true,
					fontSize: _fontSize[2],
					fontFamily: 'PMingLiU',
					distance: 20,
					color: '#d0d0d0'
				},
				emphasis: {
					show: false
				}
			},
			itemStyle: {
				normal: {
					areaColor: '#fffddc',
					borderColor: '#3086d1'
				},
				emphasis: {
					areaColor: '#fffddc'
				}
			}
		},
		backgroundColor: {
			type: 'radial',
			x: 0.5,
			y: 0.5,
			r: 1,
			colorStops: [{
				offset: 0.2,
				color: '#58c4f3' //'rgba(95, 198, 241, 0.96)'
			}, {
				offset: 1,
				color: '#0064b1'
			}],
			globalCoord: false // 缺省为 false
		},
		tooltip: {
			trigger: 'item' // 悬浮显示
		},
		series: [{
			name: '人力数据',
			type: 'scatter',
			coordinateSystem: 'geo',
			data: myData,  // 数据处！！！！！！！！！！！！
			label: {
				normal: {
					formatter: function(obj) {
						var str = ['{text|' + obj.name + '}', '{value|' + obj.data.value[2] + '}'];
						return str.join('\n');
					},
					distance: 4,
					position: 'bottom',
					show: true,
					rich: {
						text: {
							color: '#3e4182',
							fontSize: _fontSize[2],
							fontWeight: '500',
							fontFamily: 'PMingLiU',
							align: 'center'
						},
						value: {
							color: '#b35751',
							fontSize: _fontSize[3],
							align: 'center'
						}
					}
				},
				emphasis: {
					show: true
				}
			},
			symbolSize: 10,
			encode: {
				tooltip: [2] // 数据解析 方便悬浮显示
			},
			itemStyle: {
				normal: {
					color: {
						type: 'radial',
						x: 0.5,
						y: 0.5,
						r: 1,
						colorStops: [{
							offset: 0.2,
							color: 'rgba(254, 180, 22, 0.84)'
						}, {
							offset: 0.7,
							color: '#a77305'
						}],
						globalCoord: false
					}
				}
			},
			legendHoverLink: false,
			zlevel: 1
		}]
	};
	myChart = echarts.init(document.getElementById('map-wrapper'));	//Echarts初始化DOM
	myChart.setOption(option);
	
	// 日期插件中文化
	// 如果想要显示为繁体，将plugin中的zh-TW.js 打开，复写下面相应的代码即可
	$.fn.datetimepicker.dates['zh-CN'] = {
		days: ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"],
		daysShort: ["周日", "周一", "周二", "周三", "周四", "周五", "周六", "周日"],
		daysMin:  ["日", "一", "二", "三", "四", "五", "六", "日"],
		months: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
		monthsShort: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
		today: "今天",
		suffix: [],
		meridiem: ["上午", "下午"]
	};
	
	// 日期插件相关配置
	$form_date.datetimepicker({
		language: 'zh-CN',	// 开启中文显示
		weekStart: 0,
		todayBtn: 1,
		autoclose: 1,
		startDate: '2018-01-26',
		endDate: date,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 1,
		format: 'yyyy-mm-dd'
	}).on('changeDate', function(ev){
		date = ev.currentTarget.firstElementChild.value;
		$('.table_hock').find('thead').find('.th_count').remove().end().next().empty();
		myChart.showLoading();
		loadData(date);
	});
	
	// 触发事件，访问当天的数据
	$form_date.find('input').val(date).end().trigger('changeDate');
	
	// 工具栏处相关的事件（除日期选择外）
	$btn_wrapper.find('label').on('click', function(e) {
		if(!result) { // 没有开启表格显示，跳出事件
			alert('请开启表格显示！')
			return false;
		}
		var _index = $(this).index('.tools label');
		
		// 相应的表格显示、隐藏动画（通过CSS类名的增减实现）
		$tab_centent.eq(_index).removeClass('hide').addClass('show').siblings().filter('.table_hock').removeClass('show').addClass('hide'); 
		
		// 同时，Echarts有不同的配置
		if(_index === 1) {		
			myChart.setOption({
				title: EchartConfig.title.styleOne,
				geo: {
					center: EchartConfig.center[1] // 中心位置坐标
				}
			});
			$info.find('.info_num').addClass('active');	// 城市数据表格点开时，配置不同的CSS，实现不同的UI
		} else {
			myChart.setOption({
				title: EchartConfig.title.styleTwo,
				geo: {
					center: EchartConfig.center[0] // 中心位置坐标
				}
			});
			$info.find('.info_num').removeClass('active');
		}
	});

	// 上方工具栏的上浮、下沉动画
	$btn_wrapper.find('.btn_show').on('click', function() {
		var $this = $(this),
			_result = $this.parent().hasClass('hide');
		_result ? $this.text('关闭工具栏') : $this.text('显示工具栏');
		$this.parent().toggleClass('hide').toggleClass('show');
	});
	
	// 开始表格显示、关闭的事件
	$btn_wrapper.find('.toggle input').on('click', function() {
		result = $(this).prop('checked');
		$tab_centent.filter('.table_hock.show').toggleClass('hide');
	});
	
	// 隐藏城市显示表格
	$('#city_hide').on('click', function() {
		$(this).parents('.tab_item4').removeClass('show').addClass('hide');
	});

	// 点击深圳时，有不同的逻辑判定
	// 其它情况时，Echarts直接进入loadCityTable()函数
	myChart.on('click', function(e) { // 点击事件
		if (e.name === "深圳") {
			ChangeCityName(e, ['深圳', '龍華', '觀瀾', '松崗', '福田'])
		} else if(e.name === "廣州") {
			ChangeCityName(e, ['廣州', '增城', '番禺'])
		} else {
			loadCityTable(e.name, date);
		}  
	});
	
	function ChangeCityName(e, city) {
		
		var str = '',
			obj = {  // 配置UI显示的位置
				x: 0,
				y: 0
			};
			
		obj = {
			x: e.event.offsetX - 85,
			y: e.event.offsetY - 60
		}
		
		city.forEach(function(item, index) {
			str += '<label><input type="radio" name="check_city" value="' + item + '" />' + (index === 0? '合計' : item) + '</label>';
		})
		
		$city_cell.empty().append(str);
		
		$city_cell.removeClass('hide').addClass('show').css({
			top: obj.y,
			left: obj.x
		}).find('input:checked').prop('checked', false);
		
		e.event.event.stopPropagation(); 	// 手机上的兼容
		e.event.event.preventDefault();		// 手机上的兼容
	}
	
	// 深圳 城市下，点击福田、龙华等，产生的事件
	$city_cell.on('click', 'label input', function(e) {
		var _value = this.value;
		loadCityTable(_value, date);
		e.stopPropagation();
	});
	
	// 点击其它位置时，隐藏深圳 相关的DOM UI
	$(document).on('click', function(e) {
		var $cell_city = $(e.target).parents('div'),
			result = $cell_city.hasClass('city_cell');

		if(!result && $city_cell.hasClass('show')) {
			$city_cell.removeClass('show').addClass('hide');
		}
	});
	
	// 横屏，竖屏，分辨率变换时，默认重新加载
	$(window).on('resize', function() {
		window.location.reload();
	});
	
	function loadData(date) {
		// 加载三个主要表格的数据
		$.ajax({
			url: './table_data_' + date +  '.json', // http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx
			data: {
				"action": 'getEmpBySJT_DM',
				"From": "1",
				"WorkDate": date
			},
			dataType: 'json'
		}).then(function(response) {
			var regx = /(\w+)-(\w+)-(\w+)/,
				str;
			
			regx.exec(response.time);
			str = RegExp.$1 + '年' + RegExp.$2 + '月' + RegExp.$3 + '日';
	
			window.myTable({ 
				target: _table_1,	// mytable.js相关配置
				hide_item: true,	// mytable.js相关配置
				hide_count: true,	// mytable.js相关配置
				item_count: true,	// mytable.js相关配置
			}, response);
	
			window.myTable({
				target: _table_2	// mytable.js相关配置
			}, response);
	
			window.myTable({
				count_colSpanLength: 3,// mytable.js相关配置
				target: _table_3,
				hide_item: true,
				hide_count: true,
				hide_address: true,
				item_count: true
			}, response);
			
			// 点击不同日期后，更新左下方的日期及人力数据
			$info.removeClass('hidden').find('.info_num .num').text(formatterNum(response.totalValue)).end()
				.find('.info_time .time').text(str);
		});
		
		// 地图上不同小黄点数据载入
		$.ajax({
			url: './data_' + date +  '.json', //'http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx',
			data: {
				"action": "getEmpByFac_DM",
				"From": 1,
				"WorkDate": date
			},
			dataType: 'json'
		})
		.then(function(response) {
			myData = response;
			myChart.hideLoading();
			myChart.setOption({
				series: [{
					data: convertData(myData)  // 要对数据进行对比处理，再配置入Echarts中
				}]
			});
		});
	}
	
	// 点击不同的城市，载入到ID为tab_4的DOM中
	function loadCityTable(name, date) {
		// 清空已有数据
		$tab_centent.eq(3).removeClass('hide').addClass('show').find('thead .th_count').remove().end().find('tbody').empty();
		
		$.ajax({
			url: 'cell_data.json', // 'http://10.134.98.30:99/APPHandler/CNHR_EmpActiveHandler.ashx',
			data: {
				"action": "getEmpByFacClass_DM",
				"FacName": name,
				"WorkDate": date,
				"Date": Math.random()
			},
			dataType: 'json'
		}).then(function(res) {
			window.cityTable({  // 载入数据
				target: _table_4,
			}, res);
		});
	}
	
	// 对小黄点显示的数据进行处理。 
	// 主要是对geoCoordMap中，进行遍历对比，进行坐标数据合并
	// 以及echarts小黄点不同显示配置的合并
	function convertData(data) {
		var res = [],
			configArr;
		configArr = geoConfig.filter(function(item) { // 小黄点不同显示的配置
			return item.label !== undefined;
		});
		data.forEach(function(item) { // 混合config的位置配置(并减少循环次数)
			for(var i = 0; i < configArr.length; i++) {
				var result = configArr[i].name === item.name;
				if(result) {
					item['label'] = configArr[i].label;
					configArr.splice(i, 1);
					return !result;
				}
			}
		});
		for(var i = 0; i < data.length; i++) { // 坐标相关的混合
			var geoCoord = geoCoordMap[data[i].name];
			if(geoCoord) {
				if(data[i]['label']) {
					res.push({
						name: data[i].name,
						value: geoCoord.concat(data[i].value),
						label: data[i]['label']
					});
				} else {
					res.push({
						name: data[i].name,
						value: geoCoord.concat(data[i].value)
					});
				}
			}
		}
		return res;
	}

	function formatterNum(num) {
		var arr = [],
			str = '';
		num = num + '';
		arr = num.split('').reverse();
		for(var i = 0; i < arr.length; i++) {
			str += ((i % 3 !== 0) ? '' : ',') + arr[i];
		}
		return str.substring(1).split('').reverse().join('');
	}
});