;(function(root, factory, plug) {	// 三个主要表格的渲染
	factory(root, plug);
})(window, function(root, plug) {
	var countName = ['總計', '合計'];
	
	var __DEFAULT__ = {					// 相关的默认配置
		count_colSpanLength: 4,			// thead上 '總計'占的列宽
		count_className: 'th_count', 	// thead上 '總計'行，DOM的类名
		first_className: 'vert_class',	// tbody上 每个数据渲染的第一行的DOM类名
		item_className: 'tb_count',		// tbody上 '合計'行，DOM的类名
		hide_item: false,				// 表格配置，隐藏'item'的渲染
		hide_address: false, 			// 表格配置，隐藏数据最顶级'name'的渲染，如'華南'
		item_count: false,				// 表格配置，隱藏 次级'合計’行的渲染，如'深圳'下的 '合計'
		hide_count: false				// 表格配置，隐藏 '合计'行的渲染，如'华南'一个大数据下的'合計'
	};
	
	var util = {							// 工具函数
		_extend: function(target, obj) {	// 对象的重新拷贝
			var arr1 = Object.keys(obj);
			for(var i in arr1) {
				if(target[arr1[i]] === undefined) {
					if(typeof obj[arr1[i]] === "object") {
						var str = root.JSON.stringify(obj[arr1[i]]);
						target[arr1[i]] = root.JSON.parse(str);
					} else {
						target[arr1[i]] = obj[arr1[i]];
					}
				}
			}
			return;
		},
		_cut: function(data) {				// 数据的重组，用于'廠區分佈'
			var _this = this;
			arr = [];
			data.forEach(function(item, index) {
				var arr1 = Object.keys(item);

				item.data.forEach(function(_item, index) {
					var obj = {};
					for(i in arr1) {
						if(arr1[i] !== "data") {
							obj[arr1[i]] = item[arr1[i]];
						}
					}
					obj["data"] = [];
					obj["data"][0] = {};
					util._extend(obj["data"][0], _item);
					arr.push(obj);
				})
			});
			return arr;
		},
		_sort: function(data) {  			// 数据的重排序，将重组的降序排序，用于'廠區分佈'
			data.sort(function(a, b) {
				if(a.data[0].sort > b.data[0].sort) {
					return -1;
				} else {
					return 1;
				}
			})
		},
		_formatterNum: function(num) {		// 数据的格式化 如 '1233'转化成'1,233'
			var arr = [],
				str = '';
			num = num + '';
			arr = num.split('').reverse();
			for (var i = 0; i < arr.length; i++) {
				str += ((i % 3 !== 0) ? '' : ',' ) + arr[i];
			}
			return str.substring(1).split('').reverse().join('');
		}
	}
	var __METHODS__ = {
		_init: function() {					// 初始化
			var cell_length = 0;
			for(var i = 0; i < this.target.tHead.rows[0].cells.length; i++) {
				cell_length += this.target.tHead.rows[0].cells[i].colSpan;
			}
			this.cell_length = cell_length; 			// 获取表格的列宽总数
			this.targetBody = this.target.tBodies[0];	// 获取表格tbody DOM的引用
			this.targetHead = this.target.tHead;		// 获取表格thead DOM的引用
			this.countNumber = 1;						// 行数，表格渲染中，插入新行的变量
			this.localNumber = [];						// 记录每一个顶级数据name渲染的行数，如'华南、华北'开始渲染的行数
			this.rowLength = [];						// 记录每一个顶级数据name渲染的总行数数量（当hide_count等配置不同时，这个rowLength是不一样的）
		},
		_bind: function(data) {
			var _this = this,	
				_newRow = null,
				cellNum = 0,
				level = 1;								// 插入的序号
				
			// 逻辑是先进行下方的data.forEach,再进入render
			
			var render = {
				"init": function(item, flag) {			// 初始化（flag，是类似'深圳'这样的数据，产生的一个标志位）
					var arr = Object.keys(item);
					(!flag) && (cellNum = 0);
					for(y in arr) {						// 如果render里，有相应的函数方法，则进入
						(this[arr[y]]) && (this[arr[y]](item, flag));
					}
				},
				"name": function(item, flag) {			// 渲染'name'数据，以及初始化一些数据
					var length = 0,
						countRowLength;
					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];
						if(_item["data"]) {  // 如果有类似'深圳'这样的数据，则要对行数进行统计
							length += _item["data"].length - 1;
							if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {		//	如果不隐藏'合計',并且'合计'的数据来源有数据
								length++;
							}
							// 是否隐藏子项的'合计'
							if (_this.item_count) {
								length++;
							}
						}
						length++;
					}
					
					//	如果不隐藏'合計',并且'合计'的数据来源有数据
					if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {
						length++;
					}
					
					// 渲染数据顶级数据，如'華南'時，插入新的一行（'深圳'这样的数据，不需要新启一行），并记录行数位置，及总的行数
					(!flag) && (_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1)) && (_this.localNumber.push(_this.countNumber)) && (_this.rowLength.push(length));
					
					// 判断是否隐藏区域信息和是否为类似'深圳'一样的数据
					if(!_this.hide_address || flag) {
						_newRow.classList.add(_this.first_className);	// 添加类名
						_this._insertCell(_newRow, cellNum, item.name, undefined,( (_this.item_count && flag ) ? ++length : length));	// 插入新的单元格，并写入数据
						cellNum++; 	// 单元格数+1，为同行的下一个数据写入做准备
					}
				},
				
				"data": function(item, flag) { // 写入除'name'之外的其它数据
					var _that = this;

					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];

						if(!flag) {	// 插入序号。如果不是'深圳'类似的数据。
							_this._insertCell(_newRow, cellNum, level, undefined, (_item["data"] ? (!_this.hide_count || _this.item_count) ? _item.data.length + 1 : _item.data.length : 0));
							level++;
							cellNum++;
						}
						if(_item["data"]) {		//如果数据有类似'深圳'一样的数据，则重新进入render.init
							_that.init(_item, true);
						} else {				// 没有，则开始插入其它数据
							_this._insertData(_newRow, cellNum, _item.name, !flag ? 2: undefined, _item.totalValue, _item["item"]);	// 插入厂区名字
							_this.countNumber++;		// 行数+1
							if(item.data.length > 1) {	// 如果'华南'这样的数据下，data里数据量大于一，则插入新行
								_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
								cellNum = 0;
							}
						}
					}
					
					// 是否显示item,totalItem数据的渲染，以及对类似'深圳'这样的数据，单独判断
					if( (!_this.hide_count && item.totalItem.length > 1) || (flag && _this.item_count) ) {
						_newRow.classList.add(_this.item_className);		//添加类名
						
						_this._insertData(_newRow, cellNum, countName[1], ((flag) ? undefined : 3), item.totalValue, item.totalItem);		// 进入_insertData()函数,添加数据
						
						_this.countNumber++;
						_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
						cellNum = 0;
					}
					
					// 删除添加的空行
					if (_this.countNumber > 1 && !flag && item.data.length > 1) {
						_this.targetBody.deleteRow(_this.countNumber - 1);
					}
				}
			}
			
			data.forEach(function(item, index) {  // 逻辑先进入这里
				var _newRow = null,
					_cellNumber = 0,
					arr = Object.keys(item);
				render.init(item);				
				if(_this.hide_item && _this.hide_count && !_this.hide_address) {  // 渲染'区域分布'中，'华南,华北' 合计列 的数据
					_newRow = _this.targetBody.rows[_this.localNumber[index] - 1];
					_cellNumber = _newRow.cells.length;
					_this._insertCell(_newRow, _cellNumber++, item.totalValue, undefined, _this.rowLength[index]);		// 插入总数
				}
			});

		},
		tableHead: function(data) {		// 插入thead中 '總計'的数据
			var cellNum = 0,
				_newRow;
			
			_newRow = this._insertRow(this.targetHead, this.targetHead.rows.length);
			_newRow.classList.add(this.count_className);

			this._insertCell(_newRow, cellNum, countName[0], this.count_colSpanLength); //插入人数
			cellNum++;

			if(!this.hide_item) {		// 如果不是'次集团分布'的表格，则渲染totalItem中的数据
				this._insertCell(_newRow, cellNum, util._formatterNum(data.totalValue), this.cell_length - this.count_colSpanLength - data.totalItem.length);
				cellNum++;
				for(var i = 0; i < data.totalItem.length; i++) { // 插入item数据
					this._insertCell(_newRow, cellNum, data.totalItem[i]);
					cellNum++;
				}
			} else {	// 如果是，则只要插入totalValue
				this._insertCell(_newRow, cellNum, util._formatterNum(data.totalValue), this.cell_length - this.count_colSpanLength);
			}
			_newRow = null;
		},
		
		
		_insertData: function(dom, num, name, colSpan, totalValue, data) {
			this._insertCell(dom, num, name, colSpan);	// 插入一个单元格（name数据）
			num++;
			this._insertCell(dom, num, totalValue); //插入人数
			num++;
			if(!this.hide_item) {
				for(var i = 0; i < data.length; i++) { // 插入item数据
					this._insertCell(dom, num, data[i]);
					num++;
				}
			}
		},
		_insertRow: function(dom, rowNum) { //插入tr一行
			dom.insertRow(rowNum);
			return dom.rows[rowNum];
		},
		_insertCell: function(dom, cellNum, text, colSpan, rowSpan) { //插入td一个单元格
			var str = " ";
			dom.insertCell(cellNum);
			(colSpan) && (dom.cells[cellNum].colSpan = colSpan || 1);
			(rowSpan) && (dom.cells[cellNum].rowSpan = rowSpan || 1);
			(text === 0) && (text = str);
			dom.cells[cellNum].appendChild(document.createTextNode(text));
		}
	};

	root[plug] = function(options, data) {
		util._extend(options, __DEFAULT__);		// 合并__DEFAULT__的配置
		util._extend(options, __METHODS__);		// 合并__METHODS__的配置
		options._init();
		options.tableHead(data);				// 插入thead处的数据
		if(options.hide_item && options.hide_count && options.hide_address) {		// '厂区分布'时，数据进行预处理
			data.data = util._cut(data.data);
			util._sort(data.data);
		}
		options._bind(data.data);	// 渲染tbody中的数据
	}
}, "myTable");

;(function(root, factory, plug) {	// 渲染点击不同的城市，显示的表格,逻辑大体与"myTable"插件一致，区别只是需求的细节处理
	factory(root, plug);
})(window, function(root, plug) {
	
	var countName = ['總計', '合計'];
	
	var __DEFAULT__ = {
		count_colSpanLength: 4,
		count_className: 'th_count',
		first_className: 'vert_class',
		item_className: 'tb_count',
		hide_item: false,
		hide_address: false, 
		item_count: false,
		hide_count: false 
	};
	var util = {
		_extend: function(target, obj) {
			var arr1 = Object.keys(obj);
			for(var i in arr1) {
				if(target[arr1[i]] === undefined) {
					if(typeof obj[arr1[i]] === "object") {
						var str = root.JSON.stringify(obj[arr1[i]]);
						target[arr1[i]] = root.JSON.parse(str);
					} else {
						target[arr1[i]] = obj[arr1[i]];
					}
				}
			}
			return;
		},
		_formatterNum: function(num) {		// 用于数据中的格式化 '1233'转化为'1,233'
			var arr = [],
				str = '';
			num = num + '';
			arr = num.split('').reverse();
			
			for (var i = 0; i < arr.length; i++) {
				str += ((i % 3 !== 0) ? '' : ',' ) + arr[i];
			}
			
			return str.substring(1).split('').reverse().join('');
		}
	}
	var __METHODS__ = {
		_init: function() {
			var cell_length = 0;
			for(var i = 0; i < this.target.tHead.rows[0].cells.length; i++) {
				cell_length += this.target.tHead.rows[0].cells[i].colSpan;
			}
			this.cell_length = cell_length;
			this.targetBody = this.target.tBodies[0];
			this.targetHead = this.target.tHead;
			this.countNumber = 1;
			this.localNumber = [];
			this.rowLength = [];
		},

		_bind: function(data, dataName) {
			
			var _this = this,
				_newRow = null,
				cellNum = 0,
				level = 0;

			var render = {
				"init": function(item, flag) {
					var arr = Object.keys(item);
					(!flag) && (cellNum = 0);
					for(y in arr) {
						(this[arr[y]]) && (this[arr[y]](item, flag));
					}
				},
				"name": function(item, flag) {
					var length = 0,
						countRowLength;

					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];
						if(_item["data"]) {
							length += _item["data"].length - 1;
						}
						length++;
					}
					
					if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {
						length++;
					}
					
					(!flag) && (_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1)) && (_this.localNumber.push(_this.countNumber)) && (_this.rowLength.push(length));

					if(!_this.hide_address || flag) {
						_newRow.classList.add(_this.first_className);
						_this._insertCell(_newRow, cellNum, item.name, undefined, length);
						cellNum++;
					}
				},

				"data": function(item, flag) {
					var _that = this;

					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];
						if(_item["data"]) {
							if (_item.name !== _item["data"][0].name && !flag) {
								_that.init(_item, true)
							} else {
								var data  = _item["data"][0];
								level++;
								_this._insertData(_newRow, cellNum, data.name, 2, util._formatterNum(data.totalValue), data.item);
								_this.countNumber++;
								_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
								cellNum = 0;
							}
						} else {
							level++;
							_this._insertData(_newRow, cellNum, _item.name, !flag ? 2: undefined, util._formatterNum(_item.totalValue), _item["item"]);
							_this.countNumber++;
							_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
							cellNum = 0;
						}
					}
					
					if( !_this.hide_count && item.totalItem.length > 1) {
						level++;
						_newRow.classList.add(_this.item_className);
						
						_this._insertData(_newRow, cellNum, countName[1], 2, util._formatterNum(item.totalValue), item.totalItem);
						_this.countNumber++;
						_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
						cellNum = 0;
					}
					
					if (_this.countNumber > 1 && !flag && item.data.length > 1) {
						_this.targetBody.deleteRow(_this.countNumber - 1);
					}
				}
			}
			data.forEach(function(item, index) {
				render.init(item);
			});
			
			_newRow = _this.targetBody.rows[0];
			_this._insertCell(_newRow, 0, dataName, undefined, level);
			
		},
		
		tableHead: function(data) {
			var cellNum = 0,
				_newRow;
			_newRow = this._insertRow(this.targetHead, this.targetHead.rows.length);
			_newRow.classList.add(this.count_className);
			this._insertData(_newRow, cellNum, data.name, this.count_colSpanLength, util._formatterNum(data.totalValue), data.totalItem);
			_newRow = null;
		},
		
		_insertData: function(dom, num, name, colSpan, totalValue, data) {
			this._insertCell(dom, num, name, colSpan);
			num++;
			this._insertCell(dom, num, totalValue); //插入人数
			num++;
			for(var i = 0; i < data.length; i++) { // 插入item数据
				var str = "";
				str = data[i] === 0 ? "" : ((i % 2 == 0) ? data[i] + "%" : util._formatterNum(data[i]));
				this._insertCell(dom, num, str);
				num++;
			}
		},
		_insertRow: function(dom, rowNum) { //插入tr一行
			dom.insertRow(rowNum);
			return dom.rows[rowNum];
		},
		_insertCell: function(dom, cellNum, text, colSpan, rowSpan) { //插入td一个单元格
			dom.insertCell(cellNum);
			(colSpan) && (dom.cells[cellNum].colSpan = colSpan || 1);
			(rowSpan) && (dom.cells[cellNum].rowSpan = rowSpan || 1);
			dom.cells[cellNum].appendChild(document.createTextNode(text));
		}
	};

	root[plug] = function(options, data) {
		util._extend(options, __DEFAULT__);
		util._extend(options, __METHODS__);
		
		options._init();
		options.tableHead(data);
		options._bind(data.data, data.name);
	};
}, "cityTable");