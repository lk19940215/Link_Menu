;(function(root, plug, factory){
	factory( root.jQuery, plug)
})(window, 'myValidator', function($, plug){
	var __DEFAULT__ = {
		triggerEvent: 'keyup',
		targetClass: '.form-group',
		errorMessage: '输入不合法'
	};
	
	/*require 必填项
		regex 正则验证
		length 长度限制
		minlength 最小长度
		maxlength 最大长度
		between 两者长度之间 8-8
		equalto 和XX相等
		greaterthan 大于 17
		lessthan 小于 101
		middle 两个数值之间 18-100
		integer 必须是整数
		number 必须是数字
		email 必须是邮箱地址
		moblie 必须是手机号码
		phone 必须是电话号码 xxxx-xxxxxxxx
		uri 必须是有效的统一资源标示符*/
		
	var __RULES__ = {
		require: function(){
			return this.val() != '';
		},
		regex: function(){
			return new RegExp(this.data('lk-regex')).test(this.val());
		},
		length: function(){
			return this.val().length === Number(this.data('lk-length'));
		},
		minlength: function() {
			return 	this.val().length >= Number(this.data('lk-minlength'));
		},
		maxlength: function() {
			return 	this.val().length <= Number(this.data('lk-maxlength'));
		},
		
		between: function(){
			var length = this.val().length,
				between = this.data('lk-between').split('-');
			return length >= Number(between[0]) - 1 && length <= Number(between[1]);
		},
		
		equalto: function(targetClass) {
			if ($(this.data("lk-equalto")).val()===this.val()) {
				$(this.data("lk-equalto")).parents(targetClass).removeClass("has-error").addClass("has-success").next("p").remove();
				return true;
			}
			return false;
		},
		
		greaterthan: function(){
			return this.val() > Number(this.data('lk-greaterthan'));
		},
		
		lessthan: function() {
			return this.val() < Number(this.data('lk-lessthan'));
		},
		
		middle: function() {
			var middle = this.data('lk-middle').split('-'),
				val = this.val();
			return val >= Number(middle[0]) && val <= Number(middle[1]);
		},
		
		integer: function() {
			return /^\-?[0-9]*[1-9][0-9]*$/.test(this.val());
		},
		
		number: function() {
			return $.isNumeric(Number(this.val()));
		},
		
		email: function() {
			return /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/.test(this.val());
		},
		moblie: function() {
			return /^1\d{10}$/.test(this.val());
		},
		
		phone: function() {
			return /^\d{4}\-\d{8}$/.test(this.val());
		},
		
		url : function(){
			return /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/g.test(this.val());
		},// 必须是有效的统一资源标示符
		amount : function(){
    		if(!this.val())return true;
    		return /^([1-9][\d]{0,}|0)(\.[\d]{1,2})?$/.test(this.val());
    	},
    	date : function(){//yyyy-MM-dd
    		if(!this.val())return true;
    		return /^([1-9][\d]{0,}|0)(\.[\d]{1,2})?$/.test(this.val());
    	}
	};
	
	var __PROPERTY__ = {
		
		_init: function(){
			this.$elements =  this.find('.form-group .form-control:visible');
		},
		
		_attachEvent: function(type, args) {
			this.trigger(type, args);
		},
		
		_bind: function() {
			var _this = this;
			this.$elements.on(this.triggerEvent, function(e){
				var $this = $(this),
					$parent = $this.parents(_this.targetClass),
					result = true;
					
				$parent.next().remove();
				$.each(__RULES__, function(key, func){
					if( $this.data('lk-' + key)){
						result = func.call($this, _this.targetClass);
						(!result)&&$parent.after("<p class='text-danger'>"+($this.data("lk-"+key+"-message")||_this.errorMessage)+"</p>");
						return result;//如果一处不符合，则退出验证，并附加提示信息
					}
				});
				$parent.removeClass('has-error has-success').addClass((result?'has-success':'has-error'));
			});
			
			this.on('submit',function(e){
				_this.$elements.trigger(_this.triggerEvent);
				var $parents = _this.$elements.trigger(_this.triggerEvent).parents(_this.targetClass);
				if ($parents.filter('.has-error').length == 0) {
					_this._attachEvent('success', {
						event: e
					});
				}else{
					_this._attachEvent('error', {
						event: e
					});
				}
				return false;
			});
		}
	};
	
	$.fn[plug] = function(options){
		if (!this.is('form')) {throw new Error("the target is not form tag");};
		$.extend(this, __PROPERTY__ , __DEFAULT__ , options);
		this._init();
		this._bind();
		return this;
	};
	
	$.fn[plug].extendRules= function(rules){
		$.extend(__RULES__, rules);
	};
})
