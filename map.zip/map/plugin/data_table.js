;(function(root, factory, plug) {
	factory(root, plug);
})(window, function(root, plug) {

	var __DEFAULT__ = {
		count_colSpanLength: 4,
		count_className: 'th_count',
		first_className: 'vert_class',
		item_className: 'tb_count',
		hide_item: false,
		hide_address: false, //隐藏 ‘华南，华北区域名’
		hide_count: false //隐藏表一，表四 ‘合计栏下’  此功能暂不实现
	};
	var util = {
		_extend: function(target, obj) {
			var arr1 = Object.keys(obj);
			for(var i in arr1) {
				if(target[arr1[i]] === undefined) {
					if(typeof obj[arr1[i]] === "object") {
						let str = root.JSON.stringify(obj[arr1[i]]);
						target[arr1[i]] = root.JSON.parse(str);
					} else {
						target[arr1[i]] = obj[arr1[i]];
					}
				}
			}
			return;
		},
		_cut: function(data) {
			var _this = this;
			arr = [];
			data.forEach(function(item, index) {
				var arr1 = Object.keys(item);

				item.data.forEach(function(_item, index) {
					var obj = {};
					for(i in arr1) {
						if(arr1[i] !== "data") {
							obj[arr1[i]] = item[arr1[i]];
						}
					}
					obj["data"] = [];
					obj["data"][0] = {};
					util._extend(obj["data"][0], _item);
					arr.push(obj);
				})
			});
			return arr;
		},
		_sort: function(data) {
			data.sort(function(a, b) {
				if(a.data[0].totalValue > b.data[0].totalValue) {
					return -1;
				} else {
					return 1;
				}
			})
		}
	}
	var __METHODS__ = {
		_init: function() {
			var cell_length = 0;
			for(var i = 0; i < this.target.tHead.rows[0].cells.length; i++) {
				cell_length += this.target.tHead.rows[0].cells[i].colSpan;
			}
			this.cell_length = cell_length;
			this.targetBody = this.target.tBodies[0];
			this.targetHead = this.target.tHead;
			this.countNumber = 1;
			this.localNumber = [];
			this.rowLength = [];
		},

		_bind: function(data) {
			// 先插入行，再获取行进行赋值？？ 需要一个数组存储？？
			var _this = this,
				_newRow = null,
				cellNum = 0,
				level = 1;

			var render = {
				"init": function(item, flag) {
					var arr = Object.keys(item);
					(!flag) && (cellNum = 0);
					for(y in arr) {
						(this[arr[y]]) && (this[arr[y]](item, flag));
					}
				},
				"name": function(item, flag) {
					var length = 0,
						countRowLength;

					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];
						if(_item["data"]) {
							length += _item["data"].length - 1;
							if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {
								length++;
							}
						}
						length++;
					}
					if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {
						length++;
					}

					(!flag) && (_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1)) && (_this.localNumber.push(_this.countNumber)) && (_this.rowLength.push(length));

					if(!_this.hide_address || flag) {
						_newRow.classList.add(_this.first_className);
						_this._insertCell(_newRow, cellNum, item.name, undefined, length);
						cellNum++;
					}
				},

				"data": function(item, flag) {
					var _that = this;

					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];

						if(!flag) { // 插入序号
							_this._insertCell(_newRow, cellNum, level, undefined, (_item["data"] ? (!_this.hide_count) ? _item.data.length + 1 : _item.data.length : 0));
							level++;
							cellNum++;
						}
						if(_item["data"]) {
							_that.init(_item, true);
						} else {
							_this._insertCell(_newRow, cellNum, _item.name, !flag ? 2 : undefined);
							cellNum++;

							_this._insertCell(_newRow, cellNum, _item.totalValue); //插入人数
							cellNum++;

							if(!_this.hide_item) {
								for(var z = 0; z < _item["item"].length; z++) { // 插入item数据
									_this._insertCell(_newRow, cellNum, _item["item"][z]);
									cellNum++;
								}
							}
							_this.countNumber++;
							if(item.data.length > 1) { // 判断只是为了减少生成空白的tr行
								_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
								cellNum = 0;
							}
						}
					}

					if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {
						_newRow.classList.add(_this.item_className);

						// 此处设置 “合计”显示，数据结构类似 华南->深圳的组合，都要在此判断item.name
						_this._insertCell(_newRow, cellNum, "合计", (item.name === "深圳") ? undefined : 3); //插入人数
						cellNum++;

						_this._insertCell(_newRow, cellNum, item.totalValue); //插入人数
						cellNum++;

						if(!_this.hide_item) {
							for(var i = 0; i < item.totalItem.length; i++) { // 插入item数据
								_this._insertCell(_newRow, cellNum, item.totalItem[i]);
								cellNum++;
							}
						}
						_this.countNumber++;
						_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
						cellNum = 0;
					}
				}
			}
			data.forEach(function(item, index) {
				var _newRow = null,
					_cellNumber = 0,
					arr = Object.keys(item);
				render.init(item);

				if(_this.hide_item && _this.hide_count && !_this.hide_address) {
					_newRow = _this.targetBody.rows[_this.localNumber[index] - 1];
					_cellNumber = _newRow.cells.length;
					_this._insertCell(_newRow, _cellNumber++, item.totalValue, undefined, _this.rowLength[index]);
				}

			});

		},
		tableHead: function(data) {
			var allTotalValue = 0,
				allTotalItem = [],
				cellNum = 0,
				_newRow;

			data.forEach(function(item, index) {
				if(!item.totalItem.length) return false;
				allTotalValue += item.totalValue;

				if(!allTotalItem.length) {
					allTotalItem = item.totalItem;
				} else {
					allTotalItem = allTotalItem.map(function(_z, _index) {
						return _z + item.totalItem[_index];
					})
				}
			});

			_newRow = this._insertRow(this.targetHead, this.targetHead.rows.length);
			_newRow.classList.add(this.count_className);

			this._insertCell(_newRow, cellNum, "总计", this.count_colSpanLength); //插入人数
			cellNum++;

			if(!this.hide_item) {
				this._insertCell(_newRow, cellNum, allTotalValue, this.cell_length - this.count_colSpanLength - allTotalItem.length); //插入人数
				cellNum++;
				for(var i = 0; i < allTotalItem.length; i++) { // 插入item数据
					this._insertCell(_newRow, cellNum, allTotalItem[i]);
					cellNum++;
				}
			} else {
				this._insertCell(_newRow, cellNum, allTotalValue, this.cell_length - this.count_colSpanLength);
			}
			_newRow = null;
		},
		_insertRow: function(dom, rowNum) { //插入tr一行
			dom.insertRow(rowNum);
			return dom.rows[rowNum];
		},
		_insertCell: function(dom, cellNum, text, colSpan, rowSpan) { //插入td一个单元格
			var str = " ";
			dom.insertCell(cellNum);
			(colSpan) && (dom.cells[cellNum].colSpan = colSpan || 1);
			(rowSpan) && (dom.cells[cellNum].rowSpan = rowSpan || 1);
			(text === 0) && (text = str);
			dom.cells[cellNum].appendChild(document.createTextNode(text));
		}
	};

	root[plug] = function(options, data) {
		util._extend(options, __DEFAULT__);
		util._extend(options, __METHODS__);

		options._init();
		options.tableHead(data);

		if(options.hide_item && options.hide_count && options.hide_address) {
			data = util._cut(data);
			util._sort(data);
		}

		options._bind(data);
	}

}, "myTable");