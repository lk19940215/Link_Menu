
          
          
           {
                    "featureType": "city",		//显示城市名字
                    "elementType": "all",
                    "stylers": {
                              "visibility": "off"
                    }
          },
          {
                    "featureType": "district",  //显示区县名字
                    "elementType": "all",
                    "stylers": {
                              "visibility": "on"
                    }
          },
          {
                    "featureType": "town",		//显示城镇名字
                    "elementType": "all",
                    "stylers": {
                              "visibility": "off"
                    }
          },
          {
                    "featureType": "boundary",  // 国际线，省际线
                    "elementType": "all",
                    "stylers": {
                              "color": "#6fa8dcff"
                    }
          },
          {
                    "featureType": "poilabel",  //显示机场、旅游景点这些
                    "elementType": "all",
                    "stylers": {
                              "visibility": "off"
                    }
          },
          {
                    "featureType": "land",  //陆地颜色，显示
                    "elementType": "all",
                    "stylers": {
                              "color": "#eeeeeeff",
                              "visibility": "on"
                    }
          },
          {
                    "featureType": "water",	// 水系
                    "elementType": "all",
                    "stylers": {
                              "color": "#93c47dff",
                              "visibility": "on"
                    }
          },
          {
                    "featureType": "green", //绿地
                    "elementType": "all",
                    "stylers": {
                              "color": "#e06666ff",
                              "visibility": "on"
                    }
          }