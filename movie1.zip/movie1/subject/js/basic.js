$(function() {
	var $div = $(".right");
	var $like = $div.siblings(".like");
	var $more = $div.find(".more");
	var $box = $like.find(".box span")
	var $comment = $div.find(".comments-hd span:first");
	var $animate = $(".comment").find(".imgShow img");
	var $close = $(".close");
	var $btnClose = $close.prev(".btn").find("input:first");
	var $left = $(".left");
	var $labelList = $left.find(".tag-list label");
	
	var url = "../subject/movie_subject.html";  /*默认URL  下方猜你喜欢时要使用*/
	var _globalData = {}, _commentData = {}, _data = {}, _commenData = {}, _aSize = 0, _page = 0, _pageSize = 0, _likeSize = 6; /*用于翻页、定义猜你喜欢的个数、数据缓存等功能*/
	var evTimeStamp = 0; /*用于label点击时，因为和input关联会导致两次触发，而设立的变量*/
	var _id = window.location.search.match(/([0-9]+)/)[0];		/*获取具体ID*/
	var _Page = window.location.search.match(/[0-9]+$/)[0];		/*获取分页*/
	console.log(_id);
	console.log(_Page);
	
	init();  	/*初始化页面 ：初始数据判断加载        一堆垃圾代码，看后续给的目标再决定是否更改*/
	
	/*加载更多评论  点击事件*/
	$more.find("p").on("click", function() {
		var _bd_text = $div.find(".comments-bd:last dt span").html();
//		console.log(_bd_text);
//		var _data = _commentData.rows;
		$.each(_commenData, function(i, item) {
			if(item.userid == _bd_text) {
				var _i = i;
				for(var j = 1; j < 3; j++) {
				commentAppend(_commenData[_i + j],$more);/*函数调用，插入评论   function b2(){}*/
				}
			}
		});
		return false;
	});
	
	/*子页面点击回到主页事件*/
	$labelList.on("click",function(){
		var _type = $(this).text();
		var now = +new Date();
		var url = '../index/index.html?page='+encodeURI(_Page)+'&type='+encodeURI(_type);
		if (now - evTimeStamp < 100){
			return;
		}
		evTimeStamp = now;
		console.log(url);
		windowOpen(url);
	});
	function windowOpen(URL) {
			window.open(URL,"_blank");
			window.opener=null;
			window.open("","_top");
			window.close();
	}
	/* 评论框关闭事件*/
	$close.on("click", function() {
		$(".recover").addClass("hidden");
		$(".comment").addClass("hidden");
		return false;
	});
	/*评论 打分 动画*/
	$animate.on("mouseover", function() {
		var str = ["很差", "较差", "还行", "推荐", "力荐"];
		var $this = $(this);
		var _index = $this.index();
		$this.siblings().attr("src", "img/star_hollow_hover.png");
		$this.attr("src", "img/star_onmouseover.png").prevAll().attr("src", "img/star_onmouseover.png");
		$this.parent().siblings(".text").html(str[_index]);
	});
	/*参与评论点击事件*/
	$comment.on("click", function() {
		$(".recover").removeClass("hidden");
		$(".comment").removeClass("hidden");
		return false;
	});
	
	function init() {
	/*
	 *一：编剧信息有些没有；默认显示编剧为导演
	 *二：评分信息有些没有；默认显示6.0
	 *三：演员默认显示5个
	 * */
	$.getJSON("../data/data"+_Page+".json", function(data) {
		_page = data.page;
		_pageSize = data.pagesize;
		_data = data.rows;
		
		/*猜你喜欢 内容添加*/
		
		var _likearr = getnumArr(_pageSize,Math.floor(Math.random()*_likeSize),_likeSize);
//		console.log(_likearr);
		$.each(_likearr, function(index,item) {
			subjectAppend(_data[item],$box,_page);   /*原代码  function a2()*/
		});
		
		/*电影内容绑定*/
		$.each(_data, function(index, item) {
			var _title = $div.find(".title");
			var _info = $div.find(".info");
			var _sidebar = $div.find(".sidebar");
			var _power = _sidebar.find(".power");
			if(item._id == _id) {
				var _text = item.title.split(" ")[0];
				var _starScoreArr = ["4.8","19.3","53.8","17.3","4.8"];
				var _director = (item.director.match(/.+<\/a\>/)!= null)?item.director.match(/.{2,8}<\/a\>/):item.director; /*此句有问题，但是满足了要求，暂不更改*/						
				_title.find("span:first").html(_text).next().html("(" +item.releaseDate.split("-")[0] + ")");
				_title.find("img").find("img").attr({"src":item.cover,"alt":_text,"title":_text});
				_info.find(".director").html(_director);
				_info.find(".scenarist").html(_director);
				_info.find(".actors").html((typeof item.stars == "string")?item.stars:item.stars.slice(0,5).join("/"));
				_info.find(".type").html((typeof item.type == "string")?item.type:item.type.join("/"));
				_info.find(".runtime").html(item.runtime+"分钟");
				_info.find(".date").html(item.releaseDate);
				_info.find(".abstracts").html(item.abstract).parent().append("<span>(展开全部)</span>");
				_sidebar.find(".score strong").html((item.score == 0)?item.score:item.score.toFixed(1));
				_sidebar.find(".score p").html("<span>"+item.votes+"</span>" +"人评价");
				
				
				$div.find(".comments-hd dd h3 span:first").html(_text).next().html(item.commoncount);
				for(var i = 0; i < _power.length; i++) {
					var _width = (item.starsScore!= undefined)?Number(item.starsScore[i]):Number(_starScoreArr[i]);
					var _starsScore =(item.starsScore!= undefined)?item.starsScore[i]:_starScoreArr[i];
//					console.log(Number(_starScoreArr[i]));
//					console.log(_width);
					_power.eq(i).css("width", _width).next("span").html(_starsScore + "%");
				}
			}
		});
	});
		$.getJSON("../data/"+_id+"comment.json", function(data) {
			_commenData = data.rows;
//			$.extend(_commentData,data);
			$.each(_commenData, function(j, item) {
				if(j < 1) {
					commentAppend(this,$more);  /*函数调用，插入评论  function b1(){}*/
				}
			});
		});
	}
	
	function subjectAppend(scope,target,page) {
		var $this = scope;
		var _thisText= $this.title.split(" ")[0]; /*对电影名进行预处理，节省代码量*/
		var _clone = $div.find("a.templet").clone().removeClass("templet");/*寻找克隆模板（有模板的目的是，如果存在事件，也可以将事件复制过来）*/
		_clone.attr("href",url+"?key="+$this._id+"&page="+page);/*传入href*/
		_clone.find("img").attr({"src":$this.cover,"alt":_thisText,"title":_thisText});/*传入图片*/
		_clone.find("span:first").html(_thisText);/*传入电影名*/
		_clone.find("span:last").html(($this.score == 0)?0:$this.score.toFixed(1));/*传入电影评分*/
		_clone.insertBefore(target);/*将DOM插入HTML文档中*/
	}
	
	function commentAppend(scope,target){
		var $this = scope;
		var _clone = $div.find("dl.templet").clone().removeClass("templet");
//		_clone.find("img").attr("src", data[j].src);
//		_clone.find("strong").html(data[j].title);
		_clone.find("dt span:first").html($this.userid);
		_clone.find("dt span:last-child").html($this.commdate);
		_clone.find("dd p:last").html($this.common);
		_clone.insertBefore(target);
	}
	
	function getnumArr(numSum,initNum,likeSize){/*依次为：数据总数（猜你喜欢数据总过有多少个）、第一个可能的值、数组个数*/
		var newArr = [];
		if(newArr.length < likeSize){
			for (var i=0;i< likeSize;i++){
				newArr[i] = Math.floor(Math.random()*(numSum - initNum) + initNum);
				for(var j=0;j<i;j++){
					if(newArr[i] == newArr[j]){
						newArr[i] = Math.floor(Math.random()*(numSum - initNum) + initNum);
						j=-1;
					}
				}
			}
		}
		return newArr;
	}
});
