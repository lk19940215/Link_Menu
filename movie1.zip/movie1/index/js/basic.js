$(function() {
	var $div = $(".right");
	var $like = $div.siblings(".like");
	var $box = $like.find(".box span")
	var $more = $div.find(".more");
	var $nav = $div.find(".bs-nav");
	var $navA = $nav.find("a");
	var $tag = $(".tag-list");
	var $footer = $(".footer");
	var $footerDiv = $footer.find(".box2 span");
	var url = "../subject/movie_subject.html"; /*下方a标签默认URL链接*/
	var $globalData = {},$likeData = {} , _data = {}, _likedata = {},
		_aSize = 0, _page = 0, _pageSize = 0, _likeSize = 6
		_userpage = 0, _userpageSize = 0, _userdata = {}; /*用于翻页、定义猜你喜欢的个数、数据缓存等功能*/
	
	var args = {}, items = [], item = [], name = null, value = null;
	_page = (window.location.search.match(/\b[0-9]+/) == null)?0:window.location.search.match(/\b[0-9]+/)[0];
	console.log(_page);
	
	/*以下代码用于寻找第二、第三个及以上的URL上的参数*/
	items = window.location.search.substring(1).split("&");
	for(var i in items)
	{
		item = items[i].split("=");
		args[item[0]] = decodeURI(item[1]);
	}
	
	
	
	/*左侧导航点击添加样式事件*/
	$tag.find("label").on("click", function() {
		$(this).addClass("active").siblings().removeClass("active");
		return false;
	});
	maininit();/*右侧电影内容、下方猜你喜欢 数据获取及初始化添加*/
	userSeeinit();/*用户已观看数据获取、及初始化*/
	
	/*以下两个事件，找机会合并*/
	
	/*主页面加载更多  点击事件*/
	$more.find("button").on("click", function() {
		var _text = $div.find("a:nth-last-of-type(1) span").html();
		var _showNum = _pageSize;
		_aSize = $div.children("a").length - 1;
//		console.log($globalData);
//		console.log(_aSize);
//		console.log(_pageSize);
	
		if (_aSize <= (_pageSize - 5)){
//			var _data = $globalData.rows;
//			console.log($globalData);
			$.each(_data, function(i, item) {
				if(item.title.split(" ")[0] == _text) {
					var _i = i;
					for(var j = 1; j < 6; j++) {
						appendA(_data[_i + j],$nav,_page);/*原代码  function a3()*/
					}
				}
			});
		}else{
			$nav.removeClass("hidden");
			$more.find("button").prop("disabled",true).css({"background-color":"#C0C0C0"});
		}
	});
	
	
	/*用户已观看加载更多  点击事件*/
	$footer.find("button").on("click", function() {
		var _text = $footer.find("a:nth-last-of-type(1) span").html();
		_aSize = $footerDiv.parent().children("a").length;
		console.log(_text);
		console.log(_userdata);
		console.log(_aSize);
		console.log(_userpageSize);
		if (_aSize <= (_userpageSize - 5)){
			$.each(_userdata, function(i, item) {
				if(item.title.split(" ")[0] == _text) {
					var _i = i;
					for(var j = 1; j < 7; j++) {
						appendA(_userdata[_i + j],$footerDiv,_userpage);/*原代码  function a3()*/
					}
				}
			});
		}else{
//			$nav.removeClass("hidden");
			$footer.find(".more button").prop("disabled",true).css({"background-color":"#C0C0C0"});
		}
	});
	
	/*分页事件*/
	$navA.on("click",function(){
		var $this = $(this);
		_page = Number($this.html());
		removeA();
		maininit();
		return false;
	});
	
	
	function maininit() {
		/*初始化页面*/
		$.getJSON("../data/data"+_page+".json", function(data) {
			_page = data.page;
			_pageSize = data.pagesize;
			_data = data.rows;
//			console.log(_page);
			
//			$.extend($globalData,data);/*可作为数据缓存使用,当点击加载更多时，不需重新访问数据库*/
			
			$.each(_data, function(i, item) {
				if(i < 10) {
//					console.log(this);
					appendA(this,$nav,_page);/*原代码  function a1()*/
				}
			});
			
			/*猜你喜欢 内容添加*/
			var _likearr = getnumArr(_pageSize,Math.floor(Math.random()*_likeSize),_likeSize);
			$.each(_likearr, function(index,item) {
//				console.log(index);
//				console.log(item);
				appendA(_data[item],$box,_page);   /*原代码  function a2()*/
			});
		});
		$nav.addClass("hidden");    /*分页列表标签初始化*/
		$more.find("button").prop("disabled",false).removeAttr("style");/*加载更多标签初始化*/
	}
	
	function userSeeinit(){
		$.getJSON("../data/data"+_userpage+".json", function(data) {
			_userpage = data.page;
			_userpageSize = data.pagesize;
			_userdata = data.rows;
//			$.extend($likeData,data);
			$.each(_userdata, function(i, item) {
				if(i < 12) {
//					console.log(this);  $footerDiv
					appendA(this,$footerDiv,_userpage);/*原代码  function a1()*/
				}
			});
		});
	}
	
	function removeA() {
		 $div.children("a:not(.templet)").remove();
		 $like.find("a").remove();
//		$footerDiv.siblings("a").remove();
	}
	function appendA(scope,target,page) {
		var $this = scope;
//		console.log(scope)
//		console.log($(scope))
//		console.log($(scope)[0])
//		var $this = ($(scope)[0] == undefined)?scope:$(scope)[0];  /*对传入对象是this,和某一DOM对象分别做处理*/
		var _thisText= $this.title.split(" ")[0]; /*对电影名进行预处理，节省代码量*/
		var _clone = $div.find(".templet").clone().removeClass("templet");/*寻找克隆模板（有模板的目的是，如果存在事件，也可以将事件复制过来）*/
		_clone.attr("href",url+"?key="+$this._id + "&page="+page);/*传入href*/
		_clone.find("img").attr({"src":$this.cover,"alt":_thisText,"title":_thisText});/*传入图片*/
		_clone.find("span:first").html(_thisText);/*传入电影名*/
		_clone.find("span:last").html(($this.score == 0)?0:$this.score.toFixed(1));/*传入电影评分*/
		_clone.insertBefore(target);/*将DOM插入HTML文档中*/
	}
	
	function getnumArr(numSum,initNum,likeSize){/*依次为：数据总数（猜你喜欢总过有多少个）、第一个可能的值、数组个数*/
		var newArr = [];
		if(newArr.length < likeSize){
			for (var i=0;i< likeSize;i++){
				newArr[i] = Math.floor(Math.random()*(numSum - initNum) + initNum);
				for(var j=0;j<i;j++){
					if(newArr[i] == newArr[j]){
						newArr[i] = Math.floor(Math.random()*(numSum - initNum) + initNum);
						j=-1;
					}
				}
			}
		}
		return newArr;
	}
});

