/*
 *此文件夹代码，为basic.js里删除、注解的function a1(){}/ function a2(){}/function a3(){}
 * 
 * */
	function a1(){
		var _itemText = item.title.split(" ")[0]; /*对电影名进行预处理，节省代码量*/
		var _clone = $div.find(".templet").clone().removeClass("templet");/*寻找克隆模板（有模板的目的是，如果存在事件，也可以将事件复制过来）*/
		_clone.attr("href",url+"?key="+item._id);/*传入href*/
		_clone.find("img").attr({"src":item.cover,"alt":_itemText,"title":_itemText});/*传入图片*/
		_clone.find("span:first").html(_itemText);/*传入电影名*/
		_clone.find("span:last").html((item.score == 0)?0:item.score.toFixed(1));/*传入电影评分*/
		_clone.insertBefore($nav);/*将DOM插入HTML文档中*/
	}
	
	function a2(){
		var _dataText = _data[_num].title.split(" ")[0];
		var _clone = $div.find(".templet").clone().removeClass("templet");
		_clone.attr("href", url+"?key="+ _data[_num]._id);
		_clone.find("img").attr({"src":_data[_num].cover,"alt":_dataText,"title":_dataText});
		_clone.find("span:first").html(_dataText);
		_clone.find("span:last").html((_data[_num].score == 0)?0:_data[_num].score.toFixed(1));
		_clone.insertBefore($box);
	}
	
	function a3(){
		var _dataText = _data[_i + j].title.split(" ")[0];
		var _clone = $div.find(".templet").clone().removeClass("templet");
		_clone.attr("href",url +"?key=" + _data[_i + j]._id);
		_clone.find("img").attr({"src":_data[_i + j].cover,"alt":_dataText,"title":_dataText});
		_clone.find("span:first").html(_dataText);
		_clone.find("span:last").html((_data[_i + j].score == 0)?0:_data[_i + j].score.toFixed(1));
		_clone.insertBefore($nav);
	}
	
	function b1(){
		
//					var _clone = $div.find("dl.templet").clone().removeClass("templet");
////					_clone.find("img").attr("src", data[j].src);
////					_clone.find("strong").html(data[j].title);
//					_clone.find("dt span:first").html(_data[j].userid);
//					_clone.find("dt span:last-child").html(_data[j].commdate);
//					_clone.find("dd p:last").html(_data[j].common);
//					_clone.insertBefore($more);
		
		
	}
	function b2(){
		
//						var _clone = $div.find("dl.templet").clone().removeClass("templet");
////								_clone.find("img").attr("src", data[_i + j].src);
////								_clone.find("strong").html(data[_i + j].title);
//						_clone.find("dt span:first").html(_data[_i + j].userid);
//						_clone.find("dt span:last-child").html(_data[j].commdate);
//						_clone.find("dd p:last").html(_data[_i + j].common);
//						_clone.insertBefore($more);
		
		
	}

$(function(){
	var $globalData = {};
	var $more = $(".right").find(".more");
	
	inin();
	bind();
	console.log($globalData);      		184/*显示只是原先定义的空对象*/
	
	$more.on("click", function() {
		console.log($globalData);   	187/*显示已经扩展为JSON里的数据*/
	});

	function inin(){
		$.getJSON("../data/data0.json", function(data){
			$.extend($globalData,data);
			console.log($globalData);	193/*显示已经扩展为JSON里的数据*/
		});
		console.log($globalData);   	195/*显示只是原先定义的空对象*/
	}
	function bind(){
		console.log($globalData);  		198/*显示只是原先定义的空对象*/
	}
	
})





	$labelList.on("click",function(){
//		console.log(1);+"&page"
		console.log(_Page);
		var url = '../index/index.html?page='+_Page;
		console.log(url);
		windowOpen(url);
//		window.open('"../index/index.html"'+_Page,"_self");  /*+"?page"*/
	});
	
	function windowOpen(URL) {
		window.open(URL,"_blank");
	}
	




	function getURLvars() {
		var _qs = (window.location.search.length > 0 ? window.location.search.substring(1):""),
			args = {},
			items = _qs.length ? _qs.split("&"):[],
			item = null,
			name = null,
			value = null,
			i = 0,
			len = items.length;
		for (i=0;i<len;i++){
			item = items[i].split("=");
			name = decodeURIComponent(item[0]);
			value = decodeURIComponent(item[1]);
			
			if (name.length){
				args[name] = value;
			}
			return args;
		}
	}
	


		var url = '../index/index.html?'+encodeURIComponent('page')+"="+encodeURIComponent(_Page)+'&'+encodeURIComponent('type')+'='+encodeURIComponent(_type);