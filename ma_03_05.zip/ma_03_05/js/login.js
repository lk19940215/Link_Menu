$(function(){
	var ERR_OK = 1,
		ERR_NO = 0,
		ERR_PASSWORDERR = 2;
	
	var $USERNAME = $('#username'),
		$PASSWORD = $('#password');
	
	$('#formLogin').myValidator({
		targetClass: '.input-group',
		triggerEvent: 'keyup'
	}).on('success',function(args){
		$.ajax({
			url: 'login.json',// 'http://10.134.98.30:99/AppHandler/CNHR_GetMac.ashx',
			data: {
				"action": 'IsLogin',
				"EmpNO": $USERNAME[0].value,
				"PassWord": $PASSWORD[0].value
			},
			dataType: 'json'
		}).then(function(res) {
			if(res.code === ERR_OK) {
				var URL = window.location.origin + window.location.pathname;
				URL = URL.replace('login.html', 'hr_emp.html')
				sessionStorage.setItem('isLogin', true)
				window.location.href = URL
			} else if (res.code === ERR_NO) {
				alert('不存在該用戶或該用戶已失效');
			} else if (res.code === ERR_PASSWORDERR) {
				alert('該用戶密碼不正確');
			} else {
				return false;
			}
		})
	}).on('error',function(args){
		return false;
	});
});