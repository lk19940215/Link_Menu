;(function(root, factory, plug) {
	factory(root, plug);
})(window, function(root, plug) {
	var countName = ['總計', '合計'];
	
	var __DEFAULT__ = {
		count_colSpanLength: 4,
		count_className: 'th_count',
		first_className: 'vert_class',
		item_className: 'tb_count',
		hide_item: false,
		hide_address: false, 
		item_count: false,
		hide_count: false
	};
	var util = {
		_extend: function(target, obj) {
			var arr1 = Object.keys(obj);
			for(var i in arr1) {
				if(target[arr1[i]] === undefined) {
					if(typeof obj[arr1[i]] === "object") {
						var str = root.JSON.stringify(obj[arr1[i]]);
						target[arr1[i]] = root.JSON.parse(str);
					} else {
						target[arr1[i]] = obj[arr1[i]];
					}
				}
			}
			return;
		},
		_cut: function(data) {
			var _this = this;
			arr = [];
			data.forEach(function(item, index) {
				var arr1 = Object.keys(item);

				item.data.forEach(function(_item, index) {
					var obj = {};
					for(i in arr1) {
						if(arr1[i] !== "data") {
							obj[arr1[i]] = item[arr1[i]];
						}
					}
					obj["data"] = [];
					obj["data"][0] = {};
					util._extend(obj["data"][0], _item);
					arr.push(obj);
				})
			});
			return arr;
		},
		_sort: function(data) {
			data.sort(function(a, b) {
				if(a.data[0].sort > b.data[0].sort) {
					return -1;
				} else {
					return 1;
				}
			})
		},
		_formatterNum: function(num) {
			var arr = [],
				str = '';
			num = num + '';
			arr = num.split('').reverse();
			for (var i = 0; i < arr.length; i++) {
				str += ((i % 3 !== 0) ? '' : ',' ) + arr[i];
			}
			return str.substring(1).split('').reverse().join('');
		}
	}
	var __METHODS__ = {
		_init: function() {
			var cell_length = 0;
			for(var i = 0; i < this.target.tHead.rows[0].cells.length; i++) {
				cell_length += this.target.tHead.rows[0].cells[i].colSpan;
			}
			this.cell_length = cell_length;
			this.targetBody = this.target.tBodies[0];
			this.targetHead = this.target.tHead;
			this.countNumber = 1;
			this.localNumber = [];
			this.rowLength = [];
		},
		_bind: function(data) {
			var _this = this,
				_newRow = null,
				cellNum = 0,
				level = 1;
			var render = {
				"init": function(item, flag) {
					var arr = Object.keys(item);
					(!flag) && (cellNum = 0);
					for(y in arr) {
						(this[arr[y]]) && (this[arr[y]](item, flag));
					}
				},
				"name": function(item, flag) {
					var length = 0,
						countRowLength;
					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];
						if(_item["data"]) {
							length += _item["data"].length - 1;
							if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {
								length++;
							}
							if (_this.item_count) {
								length++;
							}
						}
						length++;
					}
					
					if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {
						length++;
					}
					(!flag) && (_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1)) && (_this.localNumber.push(_this.countNumber)) && (_this.rowLength.push(length));
					
					if(!_this.hide_address || flag) {
						_newRow.classList.add(_this.first_className);
						_this._insertCell(_newRow, cellNum, item.name, undefined,( (_this.item_count && flag ) ? ++length : length));
						cellNum++;
					}
				},
				"data": function(item, flag) {
					var _that = this;

					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];

						if(!flag) {	
							_this._insertCell(_newRow, cellNum, level, undefined, (_item["data"] ? (!_this.hide_count || _this.item_count) ? _item.data.length + 1 : _item.data.length : 0));
							level++;
							cellNum++;
						}
						if(_item["data"]) {
							_that.init(_item, true);
						} else {
							_this._insertData(_newRow, cellNum, _item.name, !flag ? 2: undefined, _item.totalValue, _item["item"]);
							_this.countNumber++;
							if(item.data.length > 1) {
								_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
								cellNum = 0;
							}
						}
					}
					if( (!_this.hide_count && item.totalItem.length > 1) || (flag && _this.item_count) ) {
						_newRow.classList.add(_this.item_className);
						
						_this._insertData(_newRow, cellNum, countName[1], ((flag) ? undefined : 3), item.totalValue, item.totalItem);
						_this.countNumber++;
						_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
						cellNum = 0;
					}
					
					if (_this.countNumber > 1 && !flag && item.data.length > 1) {
						_this.targetBody.deleteRow(_this.countNumber - 1);
					}
				}
			}
			
			data.forEach(function(item, index) {
				var _newRow = null,
					_cellNumber = 0,
					arr = Object.keys(item);
				render.init(item);
				if(_this.hide_item && _this.hide_count && !_this.hide_address) {
					_newRow = _this.targetBody.rows[_this.localNumber[index] - 1];
					_cellNumber = _newRow.cells.length;
					_this._insertCell(_newRow, _cellNumber++, item.totalValue, undefined, _this.rowLength[index]);
				}
			});

		},
		tableHead: function(data) {
			var cellNum = 0,
				_newRow;
			
			_newRow = this._insertRow(this.targetHead, this.targetHead.rows.length);
			_newRow.classList.add(this.count_className);

			this._insertCell(_newRow, cellNum, countName[0], this.count_colSpanLength); //插入人数
			cellNum++;

			if(!this.hide_item) {
				this._insertCell(_newRow, cellNum, util._formatterNum(data.totalValue), this.cell_length - this.count_colSpanLength - data.totalItem.length);
				cellNum++;
				for(var i = 0; i < data.totalItem.length; i++) { // 插入item数据
					this._insertCell(_newRow, cellNum, data.totalItem[i]);
					cellNum++;
				}
			} else {
				this._insertCell(_newRow, cellNum, util._formatterNum(data.totalValue), this.cell_length - this.count_colSpanLength);
			}
			_newRow = null;
		},
		_insertData: function(dom, num, name, colSpan, totalValue, data) {
			this._insertCell(dom, num, name, colSpan);
			num++;
			this._insertCell(dom, num, totalValue); //插入人数
			num++;
			if(!this.hide_item) {
				for(var i = 0; i < data.length; i++) { // 插入item数据
					this._insertCell(dom, num, data[i]);
					num++;
				}
			}
		},
		_insertRow: function(dom, rowNum) { //插入tr一行
			dom.insertRow(rowNum);
			return dom.rows[rowNum];
		},
		_insertCell: function(dom, cellNum, text, colSpan, rowSpan) { //插入td一个单元格
			var str = " ";
			dom.insertCell(cellNum);
			(colSpan) && (dom.cells[cellNum].colSpan = colSpan || 1);
			(rowSpan) && (dom.cells[cellNum].rowSpan = rowSpan || 1);
			(text === 0) && (text = str);
			dom.cells[cellNum].appendChild(document.createTextNode(text));
		}
	};

	root[plug] = function(options, data) {
		util._extend(options, __DEFAULT__);
		util._extend(options, __METHODS__);
		options._init();
		options.tableHead(data);
		if(options.hide_item && options.hide_count && options.hide_address) {
			data.data = util._cut(data.data);
			util._sort(data.data);
		}
		options._bind(data.data);
	}
}, "myTable");

;(function(root, factory, plug) {
	factory(root, plug);
})(window, function(root, plug) {
	
	var countName = ['總計', '合計'];
	
	var __DEFAULT__ = {
		count_colSpanLength: 4,
		count_className: 'th_count',
		first_className: 'vert_class',
		item_className: 'tb_count',
		hide_item: false,
		hide_address: false, 
		item_count: false,
		hide_count: false 
	};
	var util = {
		_extend: function(target, obj) {
			var arr1 = Object.keys(obj);
			for(var i in arr1) {
				if(target[arr1[i]] === undefined) {
					if(typeof obj[arr1[i]] === "object") {
						var str = root.JSON.stringify(obj[arr1[i]]);
						target[arr1[i]] = root.JSON.parse(str);
					} else {
						target[arr1[i]] = obj[arr1[i]];
					}
				}
			}
			return;
		},
		_formatterNum: function(num) {
			var arr = [],
				str = '';
			num = num + '';
			arr = num.split('').reverse();
			
			for (var i = 0; i < arr.length; i++) {
				str += ((i % 3 !== 0) ? '' : ',' ) + arr[i];
			}
			
			return str.substring(1).split('').reverse().join('');
		}
	}
	var __METHODS__ = {
		_init: function() {
			var cell_length = 0;
			for(var i = 0; i < this.target.tHead.rows[0].cells.length; i++) {
				cell_length += this.target.tHead.rows[0].cells[i].colSpan;
			}
			this.cell_length = cell_length;
			this.targetBody = this.target.tBodies[0];
			this.targetHead = this.target.tHead;
			this.countNumber = 1;
			this.localNumber = [];
			this.rowLength = [];
		},

		_bind: function(data, dataName) {
			// 先插入行，再获取行进行赋值？？ 需要一个数组存储？？
			var _this = this,
				_newRow = null,
				cellNum = 0,
				level = 0;

			var render = {
				"init": function(item, flag) {
					var arr = Object.keys(item);
					(!flag) && (cellNum = 0);
					for(y in arr) {
						(this[arr[y]]) && (this[arr[y]](item, flag));
					}
				},
				"name": function(item, flag) {
					var length = 0,
						countRowLength;

					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];
						if(_item["data"]) {
							length += _item["data"].length - 1;
						}
						length++;
					}
					
					if(!_this.hide_count && item.totalValue !== 0 && item.totalItem.length > 1) {
						length++;
					}
					
					(!flag) && (_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1)) && (_this.localNumber.push(_this.countNumber)) && (_this.rowLength.push(length));

					if(!_this.hide_address || flag) {
						_newRow.classList.add(_this.first_className);
						_this._insertCell(_newRow, cellNum, item.name, undefined, length);
						cellNum++;
					}
				},

				"data": function(item, flag) {
					var _that = this;

					for(var i = 0; i < item.data.length; i++) {
						var _item = item.data[i];
						if(_item["data"]) {
							if (_item.name !== _item["data"][0].name && !flag) {
								_that.init(_item, true)
							} else {
								var data  = _item["data"][0];
								level++;
								_this._insertData(_newRow, cellNum, data.name, 2, util._formatterNum(data.totalValue), data.item);
								_this.countNumber++;
								_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
								cellNum = 0;
							}
						} else {
							level++;
							_this._insertData(_newRow, cellNum, _item.name, !flag ? 2: undefined, util._formatterNum(_item.totalValue), _item["item"]);
							_this.countNumber++;
							_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
							cellNum = 0;
						}
					}
					
					if( !_this.hide_count && item.totalItem.length > 1) {
						level++;
						_newRow.classList.add(_this.item_className);
						
						_this._insertData(_newRow, cellNum, countName[1], 2, util._formatterNum(item.totalValue), item.totalItem);
						_this.countNumber++;
						_newRow = _this._insertRow(_this.targetBody, _this.countNumber - 1);
						cellNum = 0;
					}
					
					if (_this.countNumber > 1 && !flag && item.data.length > 1) {
						_this.targetBody.deleteRow(_this.countNumber - 1);
					}
				}
			}
			data.forEach(function(item, index) {
				render.init(item);
			});
			
			_newRow = _this.targetBody.rows[0];
			_this._insertCell(_newRow, 0, dataName, undefined, level);
			
		},
		tableHead: function(data) {
			var cellNum = 0,
				_newRow;
			_newRow = this._insertRow(this.targetHead, this.targetHead.rows.length);
			_newRow.classList.add(this.count_className);
			this._insertData(_newRow, cellNum, data.name, this.count_colSpanLength, util._formatterNum(data.totalValue), data.totalItem);
			_newRow = null;
		},
		_insertData: function(dom, num, name, colSpan, totalValue, data) {
			this._insertCell(dom, num, name, colSpan);
			num++;
			this._insertCell(dom, num, totalValue); //插入人数
			num++;
			for(var i = 0; i < data.length; i++) { // 插入item数据
				var str = "";
				str = data[i] === 0 ? "" : ((i % 2 == 0) ? data[i] + "%" : util._formatterNum(data[i]));
				this._insertCell(dom, num, str);
				num++;
			}
		},
		_insertRow: function(dom, rowNum) { //插入tr一行
			dom.insertRow(rowNum);
			return dom.rows[rowNum];
		},
		_insertCell: function(dom, cellNum, text, colSpan, rowSpan) { //插入td一个单元格
			dom.insertCell(cellNum);
			(colSpan) && (dom.cells[cellNum].colSpan = colSpan || 1);
			(rowSpan) && (dom.cells[cellNum].rowSpan = rowSpan || 1);
			dom.cells[cellNum].appendChild(document.createTextNode(text));
		}
	};

	root[plug] = function(options, data) {
		util._extend(options, __DEFAULT__);
		util._extend(options, __METHODS__);
		
		options._init();
		options.tableHead(data);
		options._bind(data.data, data.name);
	};
}, "cityTable");