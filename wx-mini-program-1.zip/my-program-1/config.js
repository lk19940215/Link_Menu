const config = {
  api_base_url: 'http://bl.7yue.pro/v1/',
  appKey: ['AbhC31IG7ruCDp57']
  // RdshydjBvcYZhMZC 0
  // GgRhTjUNUYn1fHke 1
  // AbhC31IG7ruCDp57 1
  // rAZQza38jEP5A7b7 1
}

export { config }