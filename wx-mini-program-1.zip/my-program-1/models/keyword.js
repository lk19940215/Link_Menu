import { HTTP } from '../util/http-p.js'

class KeywordModel extends HTTP {
  key = 'q'
  maxLength = 10

  getHistory() {
    const words = wx.getStorageSync(this.key)
    if (!words) {
      return []
    }
    return words
  }

  getHot() {
    return this.request({
      url:'/book/hot_keyword'
    })
  }

  addToHistory(keyword) {
    let words = this.getHistory()
    const has = words.includes(keyword)
    if (!has) {
      words.unshift(keyword)
      wx.setStorageSync(this.key, words.slice(0, this.maxLength))
    } else {
      let len = words.findIndex(item => item == keyword)
      words.unshift(...words.splice(len, 1))
      wx.setStorageSync(this.key, words)
    }
  }
}

export { KeywordModel }