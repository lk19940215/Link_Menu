// components/like/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    count:{
      type: Number
    }, 
    like: {
      type: Boolean
    },
    likeSrc: {
      type: String,
      value: 'images/like.png'
    },
    unlikeSrc: {
      type: String,
      value: 'images/like@dis.png'
    },
    readOnly: { 
      type: Boolean
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onLike(event) {
      let _this = this
      let like = _this.properties.like
      let count = _this.properties.count

      if (this.properties.readOnly) {
        return
      }

      count = like ? count-1 : count+1
      _this.setData({
        count: count,
        like: !like
      })
      _this.triggerEvent("like", {
        behavior: _this.properties.like ? 'like' : 'cancel'
      })
    }
  }
})
