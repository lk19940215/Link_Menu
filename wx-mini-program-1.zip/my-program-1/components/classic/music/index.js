import { classicBeh } from './../classic-beh.js'

const mMg = wx.getBackgroundAudioManager()

Component({
  behaviors: [classicBeh],
  
  /**
   * 组件的属性列表
   */
  properties: {
    src: String,
    title: String
  },

  /**
   * 组件的初始数据
   */
  data: {
    playing: false,
    pauseSrc: './images/player@pause.png',
    playSrc: 'images/player@play.png'
  },

  attached: function() {
    this._recoverStatus()
    this._monitorSwitch()
  },

  /**
   * 组件的方法列表
   */
  methods: {
    onPlay() {
      if (!this.data.playing) {
        this.setData({
          playing: !this.data.playing
        })
        mMg.src = this.properties.src
        mMg.title = this.properties.title
      } else {
        this.setData({
          playing: !this.data.playing
        })
        mMg.pause()
      }
    },

    _recoverStatus() {
      if (mMg.paused) {
        this.setData({
          playing: false
        })
        return
      }

      if (mMg.src == this.properties.src) {
        this.setData({
          playing: true
        })
        return 
      }
    },

    _monitorSwitch() {
      mMg.onPlay(() => {
        this._recoverStatus()
      })
      mMg.onPause(() => {
        this._recoverStatus()
      })
      mMg.onStop(() => {
        this._recoverStatus()
      })
      mMg.onEnded(() => {
        this._recoverStatus()
      })
    }
  }
})
