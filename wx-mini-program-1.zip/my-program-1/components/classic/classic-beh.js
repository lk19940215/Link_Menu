let classicBeh = Behavior({
  properties: {
    img: String,
    content: String,
    hidden: Boolean
  }
})

export { classicBeh }