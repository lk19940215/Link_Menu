import { KeywordModel } from '../../models/keyword'
import { BookModel } from '../../models/book'
import { paginationBev } from '../behaviors/pagination.js'

const keyModel = new KeywordModel()
const bookModel = new BookModel()

Component({
  behaviors: [paginationBev],
  properties: {
    more: {
      type: String,
      observer: 'loadMore'
    }
  },
  data: {
    historyWords: [],
    hotKeys: [],
    q: '',
    loading: false, // 锁, 防止多次无用的加载
    loadingCenter: false,
    searching: false
  },
  attached: function () { // 组件初始化调用
    this.setData({
      historyWords: keyModel.getHistory()
    })
    keyModel
      .getHot()
      .then(res => {
        this.setData({
          hotKeys: res.hot
        })
      })
  },
  methods: {
    loadMore: function () {
      if (!this.data.q) {
        return
      }
      if (this.isLocked()) {
        return
      }
      let hasMore = this.hasMore()
      if (!hasMore) {
        return
      }
      if (this.hasMore()) {
        this.locked()
        bookModel
          .search(this.getCurrentStart(), this.data.q)
          .then(res => {
            this.setMoreData(res.books)
            this.unLocked()
          },
            () => {
              this.unLocked() // 断网后避免死锁
            }
          )
      }
    },
    onConfirm: function (event) {
      this._showResult()
      this._showLoadingCenter()
      const q = event.detail.value || event.detail.text
      this.initPagination()
      this.setData({
        q: q
      })
      bookModel
        .search(0, q)
        .then(res => {
          keyModel.addToHistory(q)
          this.setMoreData(res.books)
          this.setTotal(res.total)
          this._hideLoadingCenter()
          this.setData({
            historyWords: keyModel.getHistory()
          })
        })
    },
    onCancel: function () {
      this.initPagination()
      this.triggerEvent('cancel', {}, {})
    },
    onDelete: function () {
      this.initPagination()
      this._closeResult()
      this._hideLoadingCenter()
    },
    _showResult() {
      this.setData({
        searching: true
      })
    },
    _closeResult() {
      this.setData({
        searching: false,
        q: ''
      })
    },
    _showLoadingCenter() {
      this.setData({
        loadingCenter: true
      })
    },
    _hideLoadingCenter() {
      this.setData({
        loadingCenter: false
      })
    }
  }
})
