$(function(){
	$('#formRegist').myValidator({
		targetClass: '.input-group'
	}).on('success',function(){
		console.log(window.location.href)
		this.submit();
	}).on('error',function(){
		alert('验证失败')
	});
	
	var _$btn = $('#btnMobileValidCode');
	
	$('[name="registerParam.mobilePhone"]').on('keyup',function(){
		_$btn.prop('disabled', !$(this).parent().hasClass('has-success'));
	});
	
	var second = 10;
	
	_$btn.on('click',function(){
		var $this = $(this);
		$this.prop('disabled',true).text('请'+ second + '秒后重新获取');
		var timer = window.setInterval(function(){
			$this.text('请'+ (--second) + '秒后重新获取');
			if (second == 0) {
				window.clearInterval(timer);
				$this.prop('disabled',false).text('获取验证码');
				second = 5;
			}
		},1000);
	});
	
});