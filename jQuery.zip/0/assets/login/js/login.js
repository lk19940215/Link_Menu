$(function(){
	$('#formLogin').myValidator({
		targetClass: '.input-group'
	}).on('success',function(args){
		alert('验证成功，执行登陆程序');
		this.submit();
		return false;
	}).on('error',function(args){
		return false;
	});
//	$('#username').on('blur',function(){
//		var $parent = $(this).parents('.input-group').removeClass('has-error has-success'),
//			regx = /^\w{8,12}$/g;
//		
//		$parent.next().remove();
//		if ( regx.test(this.value)){
//			$parent.addClass('has-success');
//		}else{
//			$parent.addClass('has-error').after('<p class="text-danger">输入不合法</p>');
//		}
//	});
//	
//	
//	$('#password').on('blur',function(){
//		var $parent = $(this).parents('.input-group').removeClass('has-error has-success'),
//			regx = /^\w{8,12}$/g;
//		
//		$parent.next().remove();
//		if ( regx.test(this.value)){
//			$parent.addClass('has-success');
//		}else{
//			$parent.addClass('has-error').after('<p class="text-danger">输入不合法</p>');
//		}
//	});
//	
//	$('#verifyCode').on('blur',function(){
//		var $parent = $(this).parents('.input-group').removeClass('has-error has-success'),
//			regx = /^\w{4}$/g;
//			
//		$parent.next().remove();
//		if ( regx.test(this.value)){
//			$parent.addClass('has-success');
//		}else{
//			$parent.addClass('has-error').after('<p class="text-danger">输入不合法</p>');
//		}
//	});
//	
//	$('#formLogin').on('submit',function(e){
//		var all = $(this).find('input').blur().length,
//			success = $('.has-success').length;
//			
//		if (success == all) {
//			this.submit();
//		}else{
//			return false;
//			alert('未验证完毕');
//		}
//	});
	
	
});