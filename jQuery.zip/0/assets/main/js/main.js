$(function(){
	$('#mainForm')
		.myValidator({
			triggerEvent: 'blur',
			targetClass: '.input-group'
		}).on("success",function(){
			
		});
		
	$.getJSON("data/data1.json",function(obj){ 		// JSON文件不能有注释！！！！
//		$.MetaData(obj);
		MetaData.load(obj);// 通过图形驱动js程序,加载页面;
	});
	
	var $btns = $('#stab2 button');
	var $checkAll = $('#bankDimens span.chk-all').on('click', function(){
		var _checked = $(this).toggleClass('checked').hasClass('checked');
		_checked ? $btns.not('.checked').trigger('click') : $btns.filter('.checked').trigger('click');
	});
	
	$btns.on('click',function(){
		var $check = $(this);
		var checked = $check.toggleClass('checked').hasClass('checked');
		var checkAllLength = $check.next().prop("checked", checked).parents(".check-group").find(".btn-check.checked").length;
		checkAllLength === $btns.length ? $checkAll.addClass("checked") : $checkAll.removeClass("checked");
	});
	
	
	$("#billList tbody").on("click","tr",function(){
        $(this).find("td:first span").toggleClass("checked");
        var totalBillAmt=0,
            totalBillCnt=0,
            totalDueYield=0,
            totalInvestmentAmt=0,
            weightedAverageYield=0;
            
        $.each($(this).parent().find("td span.checked"),function(){
        	console.log($(this).data("meta"));
            var meta = $(this).data("meta");
            totalBillAmt+=meta.subscriptionAmt;
            totalBillCnt++;
            totalBillAmt+=meta.yearlyRate;
            totalInvestmentAmt+=meta.faceAmt;
            weightedAverageYield+=meta.discountRate;
        });
        
        totalBillAmt /= totalBillCnt;
        weightedAverageYield /= totalBillCnt;
        
        MetaData.load({
            detail:{
              "totalBillAmt": totalBillAmt||0,
              "totalBillCnt": totalBillCnt||0,
              "totalDueYield": totalDueYield||0,
              "totalInvestmentAmt": totalInvestmentAmt||0,
              "weightedAverageYield": weightedAverageYield||0
            }
        });
    });
	
//		$(this).toggleClass('checked');
//		var $size = $btns.filter('.checked').size();
//		if($size===$btns.length){
//          $checkAll.addClass("checked");
//      }else{
//          $checkAll.removeClass("checked");
//      }
})
