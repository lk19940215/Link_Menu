var MetaData = (function(){
	
	var __PROTOTYPE__ = {
		// 装载元数据
		load: function(metaData){
			metaData = metaData || {};
			for (var tab in metaData) {
					this[tab].load = true;
					this[tab].data = metaData[tab];
				}
			this.render();
		},
		"render": function(){	//驱动所有load为true的模块的render方法
			for (var module in this) {
				var m = this[module];
				if (m.load) {
					m.beforeRender && m.beforeRender(this);	//渲染模块之前的回调
					m.render && m.render(this);			//渲染模块
					m.afterRender && m.afterRender(this);	//渲染模块之后的回调
					m.load = false;		//渲染关闭
				}
			}
		}
		
	};
	
	return $.extend({
		"querys":{	//查询条件模块
			"querys.billAmt":null,
			"querys.discountRate":null,
			"querys.latestAccountDateFrom":null,
			"querys.latestAccountDateTo":null,
			"querys.acceptBankType":null,
			"querys.acceptBank":null,
			"pageNo":null,
			"pageSize":null,
			"totalPage":null
		},
		"detail":{	//详细数据模块
			"load":false,	//如果load为true,则调用该模块的渲染方法
			"data":null,
			"render":function(metaData){
				$.each(this.data, function(key, val) {
					var o = $('#' + key);
					o.text(Utils.numberFormat(o, val));
				});
			}
		}, 
		"invest":{	//当前可投数据
			"load":false,	//如果load为true,则调用该模块的渲染方法
			"data":null,
			"renderPie":function(metaData){
				var pie1 = document.getElementById("tab1-pie1"),
					pie1Detail = $(pie1).next(),
					myChart = echarts.init(pie1),
					option = {},
					legend = [],
					seriesData = [];
				
				for (var prop in this.data.pie1) {
					legend.push(prop);
					seriesData.push({ "value":this.data.pie1[prop], "name":prop });
					pie1Detail.append('<dl><dt>'+prop+'</dt><dd class="number" data-format-type="amount">'+this.data.pie1[prop]+'</dd><dd class="unit">元</dd></dl>');
				}
				
				options = {
					title:{
						text:"可投票据预览"
					},
					tooltip:{
						trigger: 'item',
						formatter: "{a} <br/>{b}: {c} ({d}%)"
					},
					legend:{
						borderRadius: [50,50,10,10],
						orient: 'vertical',
						x: 'right',
						y: 'bottom',
						data: legend
					},
					toolbox:{
						right: "5%",
						feature:{
							restore:{
								title:'还原'
							},
							saveAsImage:{}
						}
					},
					series:[
						{
							name:'访问来源',
							type:'pie',
							radius: ['50%', '70%'],
							avoidLabelOverlap: false,
							label: {
								normal: {
									show: false,
									position: 'center'
								},
								emphasis: {
									show: true,
									textStyle: {
										fontSize: '30',
										fontWeight: 'bold'
									}
								}
							},
							data: seriesData
						}
					]
				};
				myChart.setOption(options);
				
			},
			'renderBar':function(metaData){
				var bar = document.getElementById("tab1-bar"),
					barDetail = $(bar).siblings('.detail'),
					myChart = echarts.init(bar),
					option = {},
					xAxis = [],
					seriesData = [],
					_this = this;
				
		        myChart.on('click', function (params) {
		        	$.getJSON("data/line.json",{month:params.name},function(data){
		        		_this.renderLine(metaData,params.name,data);
		        	});
				});
				for (var prop in this.data.bar) {
					xAxis.push(prop);
					seriesData.push({ "value":this.data.bar[prop], "name":prop });
					barDetail.append('<dl><dt>'+prop+'</dt><dd class="number" data-format-type="amount">'+this.data.bar[prop]+'</dd><dd class="unit">元</dd></dl>');
				}
				options = {
					title:{
						text: "现金流量（万）"
					},
					xAxis:{
						type:'category',
						data: xAxis
					},
					yAxis:{
						type: 'value',
						boundaryGap: ["0%", "5%"],
					},
					tooltip:{
						trigger: 'item'
					},
					toolbox:{
						right: "5%",
						feature:{
							restore:{
								title:'还原'
							},
							saveAsImage:{}
						}
					},
					series:[
						{
							name:'现金流量',
							type:'bar',
							itemStyle: {
			                    normal: {
			                        color: function(params) {
			                            var colorList = ['#fbdf7f','#f3a43b','#60c0dd','#e2454e','#c6e579','#9bca63','#99ccff','#9966ff','#cc33cc','#ff7f50'];
			                            return colorList[params.dataIndex]
			                        }
			                    }
			                },
							data: seriesData
						}
					]
				};
				myChart.setOption(options);
			},
			"renderLine":function(metaData, name, data){
				
				var line = document.getElementById("tab1-line");
				$(line).show().prev().hide();
				var	myChart = echarts.init(line),
					option = {},
					xAxis = [],
					seriesData = [];
					
				for (var prop in data) {
					xAxis.push(prop);
					seriesData.push(data[prop]);
				}
				options = {
					title:{
						text: name + " 现金流量(万)",
						subtext: '日期/单位：（万）'
					},
					xAxis:{
						type:'category', //category
			            boundaryGap : false,
						data: xAxis
					},
					yAxis:{
						type: 'value',
			            axisLabel : {
			                formatter: '{value}'
			            }
					},
					tooltip:{
						trigger: 'item'
					},
					toolbox:{
						right: "5%",
						feature:{
							restore:{
								title:'还原'
							},
							saveAsImage:{}
						}
					},
					series:[
						{
							name:'最低资金',
							type:'line',
							data: seriesData
						}
					]
				};
				myChart.setOption(options);
			},
			"beforeRender":function(){
				$("#tab1-pie1").next().empty();
				$("#tab1-line").next().empty();
			},
			"render":function(metaData){
				this.renderPie(metaData);
				this.renderBar(metaData);
			}
		},
		"flow":{	//当前现金模块
			"load":false,	//如果load为true,则调用该模块的渲染方法
			"data":null,
			"render":function(metaData){
				console.log("flow======" + this);
			}
		},
		"overview":{//已选票据模块
			"load":false,	//如果load为true,则调用该模块的渲染方法
			"data":null,
			"render":function(metaData){
				console.log("overview======" + this);
			}
		},
		"forecast":{//投后现金模块
			"load":false,	//如果load为true,则调用该模块的渲染方法
			"data":null,
			"render":function(metaData){
				console.log("forecast======" + this);
			}
		},
		"list":{	//列表数据模块
			"load":false,	//如果load为true,则调用该模块的渲染方法
			"data":null,
			"target": $('#billList tbody'),
			"lazy":$("#billList .lazy-load"),
			"beforeRender":function(metaData){
				var data = this.data;
				metaData.querys.pageNo = data.pageNo;
				metaData.querys.pageSize = data.pageSize;
				metaData.querys.totalPage = data.totalPage;
				// showloading
				if(data.pageNo<data.totalPage){
					this.lazy.text("点击记载更多票据明细").prop("disabled",false);
				}else{
					this.lazy.text("已全部加载完毕").prop("disabled",true);
				}
			},
			"render":function(metaData){
				this.target.empty();
				var result = this.data.result || [];
				var $row, row;
				(this.data.result.length == 0)&&this.lazy.hide();
				for (var i = 0; i < result.length; i++) {
					row = result[i];
					$row = $("<tr>"+
								        "<td><span data-stopPropagation class=\"ico inp-check\" id=\"r"+row.id+"\"></span><input type=\"checkbox\" style=\"display:none\" value=\""+row.id+"\"></td>"+
								        //"<td><a href=\"" + ROOT +  "/invest/billInfo?id=" + row.productInfoId + "\" target=\"_blank\">"+row.billNo+"</a></td>"+
								        "<td>"+row.billNo+"</td>" +
								        "<td>"+row.acceptBankName+"</td>"+
								        "<td><span data-format-type='rate'>"+row.discountRate+"</span>%</td>"+
								        "<td><span data-format-type='amount'>"+row.faceAmt+"</span>元</td>"+
								        "<td><span data-format-type='amount'>"+row.subscriptionAmt+"</span>元</td>"+
								        "<td>"+row.remainDeadline+"天</td>"+
								        "<td>"+new Date(row.accountDate).toLocaleDateString()+"</td>"+
									   "</tr>");
									   
					$row.find("td:first span").data("meta",row);//*
					this.target.append($row);
				}
			},
			"afterRender":function(){
				// hide loading
				Utils.numberFormat();
			}
		}
	}, __PROTOTYPE__);

})();
