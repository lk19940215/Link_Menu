;(function(root, plug, factory){
	factory(root.jQuery, plug);
})(window, 'MetaData',function($, plug){
	var __PROTOTYPE__ = {
		"load":function(data){
			data = data || {};
			for (var module in data) {
				if(this[module]){
					this[module].load = true;
					this[module].data = data[module];
				}
			}
			this.render();
		},
//		在jQuery的命名空间上,存在大量的命名空间.若存在架构冲突,可能调用其它命名空间的函数。
//      故,在$上的命名扩展到此为止。采用第二种方式进行驱动编程;
		"render":function(){
			for (var module in this) {
				var m = this[module];  
				if (m.load) {
					m.beforeRender && m.beforeRender(this);	//渲染模块之前的回调
					m.render && m.render(this);			//渲染模块
					m.afterRender && m.afterRender(this);	//渲染模块之后的回调
					m.load = false;		//渲染关闭
				}
			}
		}
	};
	var  __MODULE__ = {
		"querys":{
			"load":false,
			"data":null,
			"render":function(){
				console.log("querys=====" + this);
			}
		},
		"detail":{
			"load":false,
			"data":null,
			"render":function(){
				console.log("detail=====" + this);
			}
		},
		"list":{
			"load":false,
			"data":null,
			"render":function(){
				console.log("list=====" + this);
			}
		},
		"invest":{
			"load":false,
			"data":null,
			"render":function(){
				console.log("invest=====" + this);
			}
		},
		"flow":{
			"load":false,
			"data":null,
			"render":function(){
				console.log("flow=====" + this);
			}
		},
		"overview":{
			"load":false,
			"data":null,
			"render":function(){
				console.log("overview=====" + this);
			}
		},
		"forecast":{
			"load":false,
			"data":null,
			"render":function(){
				console.log("forecast=====" + this);
			}
		}
	};
	
	$[plug] = function(data){
		$.extend(this, __MODULE__ ,__PROTOTYPE__);
		this.load(data);
	}
})