;(function(root, plug, factory){
	factory(root.jQuery, plug)
})(window, 'sectionWrap', function($, plug){
	var __PROTOTYPE__ = {
		init: function(){
			this.$sectionWrap = this.addClass('section-wrapper')
				.find('ul:first')
				.addClass('section-wrap section-animate')
				.children('li').addClass('section').end();
			this.$sections = this.$sectionWrap.find('li.section');
			this.index = 0;
			this.last = this.$sections.length - 1;
			this.lock = true;
		},
		serials: function(){
			if (!this.showSerial) { return; }
			this.$serials = $('<ul class="serial"></ul>');
			for (var i = 0; i < this.last + 1; i++) {
				this.$serials.append("<li" + (!i?' class="curr"':'') +"><a href='#'></a></li>");
			}
			this.append(this.$serials);
			this.serialsEvent();
		},
		serialsEvent: function() {
			var _this = this;
			this.$serials.on('click','li',function(){
				_this.trigger('mousewheel', [true, $(this).index()]);
			});
//			this.$serials.find('li').each(function(index,dom){
//				$(this).on('click',function(e){
//					_this.trigger('mousewheel', [true, index]);
//				});
//			};
		},
		addEvent: function(name, args){
			this.trigger(name, args);
		},
		bind: function() {
			var _this = this,
			 	dir,
			 	beforeIndex;
			this.on('mousewheel',function(e, type, index){
				if (_this.lock) {
					_this.lock = false;
					beforeIndex = _this.index;
					if (!type) {
						dir = e.originalEvent.wheelDelta < 0;
						dir? _this.index++ : _this.index--;
					}else{
						_this.index = index;
					}
					_this.index = Math.max( 0, _this.index);
					_this.index = Math.min( _this.last, _this.index);
					if (beforeIndex == _this.index) {
						_this.lock = true;
						return;
					}
					_this.addEvent('beforeWheel',{
						after : _this.index,
						afterDOM : _this.$sections.eq(_this.index),
						before : beforeIndex,
						beforeDom : _this.$sections.eq(beforeIndex)
					});
					_this.$sectionWrap.css({
						'transform': "translateY( -"+ _this.index +"00%)",
						'-webkit-transform': "translateY( -"+ _this.index +"00%)",
						'-moz-transform': "translateY( -"+ _this.index +"00%)",
						'-ms-transform': "translateY( -"+ _this.index +"00%)"
					});
					setTimeout(function(){
						_this.lock = true;
						_this.addEvent('afterWheel',{
							after : _this.index,
							afterDOM : _this.$sections.eq(_this.index),
							before : beforeIndex,
							beforeDom : _this.$sections.eq(beforeIndex)
						});
						_this.$serials
							 .children('li')
							 .eq(_this.index)
							 .addClass('curr')
							 .siblings()
							 .removeClass('curr');
					}, 1000);
				}
			});
		}
	};
	
	var __DEFAULTS__ = {
		showSerial: true
	};
	
	$.fn[plug] = function(options){
		$.extend(this, __PROTOTYPE__ , __DEFAULTS__ , options)
		this.init();
		this.bind();
		this.serials();
		return this;
	};
})

/*$(function(){
	var $sectionWrap = $('.section-wrap'),
		$header = $('header'),
		menubar = $header.find('.menubar'),
		_index = 0,
		_last = $sectionWrap.find('li').length - 1,
		_lock = true;
	
	function onBeforeMouseWheel(index){
		$header.addClass('hide');
		$(".section-2").removeClass("action");
	}
	function onAfterMouseWheel(index) {
		if (index != 0) {
			menubar.removeClass('white').addClass('black');
		}else{
			menubar.removeClass('black').addClass('white');
		}
		if (index == 1) {
			$(".section-2").addClass("action");
		}
		$header.removeClass('hide');
	}
	
	$sectionWrap.on('mousewheel',function(e){
		if (_lock) {
			_lock = false;
			var dir = e.originalEvent.wheelDelta < 0;
			var beforeIndex = _index;
			dir ? _index++ : _index--;
			_index = Math.max( 0, _index );
			_index = Math.min( _index, _last );
			if (beforeIndex == _index) {
				_lock = true;
				return;
			}
			onBeforeMouseWheel( _index );
			$sectionWrap.css({
				'transform': "translateY( -"+ _index +"00%)",
				'-webkit-transform': "translateY( -"+ _index +"00%)",
				'-moz-transform': "translateY( -"+ _index +"00%)",
				'-ms-transform': "translateY( -"+ _index +"00%)"
			});
		}
		setTimeout(function(){
			_lock = true;
			onAfterMouseWheel( _index);
		}, 1000)
		
	});
		
})
*/