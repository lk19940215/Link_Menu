$(function(){
	var $header = $('header'),
		$menubar = $header.find('.menubar');
		
	$('#sw').sectionWrap().on('beforeWheel',function(e, args){
		$header.addClass('hide');
		$(".section-2").removeClass("action");
	}).on('afterWheel',function(e, args){
		if (args.after != 0) {
			$menubar.removeClass('white').addClass('black');
		}else{
			$menubar.removeClass('black').addClass('white');
		}
		if (args.after == 1) {
			$(".section-2").addClass("action");
		}
		$header.removeClass('hide');
	});
});
